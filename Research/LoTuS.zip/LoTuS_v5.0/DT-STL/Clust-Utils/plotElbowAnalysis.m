function plotElbowAnalysis(debug)

figure();

T_seq = debug.T;
perc_gdiv_unexp_iter = debug.perc_gdiv_unexp_iter;

nTree = numel(T_seq);
for i=1:nTree
    nleaves_seq(i) = treenleaves(T_seq{i});
end

plot(nleaves_seq, perc_gdiv_unexp_iter)
xlabel('Number of leaves')
ylabel('% Diversity Unexplained')
%set(gca, 'XTick', nleaves_seq(end):nleaves_seq(1))
xlim([nleaves_seq(1)-0.5,nleaves_seq(end)+0.5]);
ylim([0,1.1]);


% % Display points
% tree_idx_seq = cellstr(num2str([1:nTree]'));
% tx = text(nleaves_seq, perc_gdiv_unexp_iter, tree_idx_seq, ...
%     'VerticalAlignment','bottom', 'HorizontalAlignment', 'left');

end