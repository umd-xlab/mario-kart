function predclass = treeClassifyObj(T, signal, node)
%treeClassifyObj (recursively) classifies ONE input signal using 
%   the constructed tree T.  

% If no node is passed. Start from root.
if nargin<3
    node = 1;
end

node_data = T.get(node);

if T.isleaf(node)   % base case
     predclass = node_data.predclass;

else % recursion case
    listchildren = T.getchildren(node);
    leftnode = listchildren(1);
    rightnode = listchildren(2);
    
    lsat = primitiveCheckSat(node_data.PSTLformula, signal);
    
    if lsat == 1 % left
        predclass = treeClassifyObj(T, signal, leftnode);
    else %0 right 
        predclass = treeClassifyObj(T, signal, rightnode);
    end
    
end
  
end

