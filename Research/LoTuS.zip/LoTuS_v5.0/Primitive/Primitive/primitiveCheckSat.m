function [lsat, robdeg] = primitiveCheckSat(PSTLprimitive, signals)
%primitiveCheckSat check satistaction of a set of signals using a PSTLprimitive
%   Output: for each signal 
%   lsat - boolean satistaction (1/0)
%   robdeg - quantitative satisfaction

fstruct = PSTLprimitive.fstruct;
fpars = PSTLprimitive.fpars;

traces = signals.traces;
t = signals.t;

robdeg  = primitiveRobustness(fstruct,fpars,traces,t);
lsat = (robdeg>=0);

end

