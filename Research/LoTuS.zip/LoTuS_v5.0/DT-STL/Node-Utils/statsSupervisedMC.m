function [stats, predclass] = statsSupervisedMC(signals, T, node_id, numclass)
%computeStats compute some stats about the current node (used for stopping)

stats.node_depth = treeNodeDepth(T, node_id);

if ~isempty(signals.traces)
    stats.nobj = size(signals.traces,1);
else
    stats.nobj = 0;
end

classes = 1:numclass;
if stats.nobj>0
    labels = signals.labels;
    bins = [classes-0.5, classes(end)+0.5];
    stats.fclass = histcounts(labels, bins, 'Normalization','probability');
    %'Normalization','count'); %'BinMethod','integers'
    [fclass_selected,idxmax] = max(stats.fclass);

    %stats.nobj_pos = sum(signals.labels == 1);
    %stats.nobj_neg = stats.nobj-stats.nobj_pos;
    %stats.fpos = stats.nobj_pos/stats.nobj;
    %stats.fneg = stats.nobj_neg/stats.nobj;
else
    stats.fclass = zeros(1,numclass);
    
    %stats.nobj_pos = 0;
    %stats.nobj_neg = 0;
    %stats.fpos = NaN;
    %stats.fneg = NaN;
end

% assign label based on majority vote
if stats.nobj==0  % if node is empty, it's arbitrary
    predclass = 2;
else
    predclass = classes(idxmax);
end

% stats for pruning

% find fraction of training objects falling in this node
if treeIsNodeRoot(T, node_id)  % is root
    stats.fobj = 1;
else
    stats.fobj = stats.nobj/T.get(1).stats.nobj;
end

% if predclass ==  1
%     stats.r_err = stats.fneg;    
% else
%     stats.r_err = stats.fpos;
% end
stats.r_err = 1 - fclass_selected;
stats.R_err = stats.r_err*stats.fobj;

end