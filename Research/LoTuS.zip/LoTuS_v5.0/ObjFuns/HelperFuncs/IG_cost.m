function val = IG_cost(p_Strue, p_Sfalse, p_Strue_Cp, p_Strue_Cn, ...
                        p_Sfalse_Cp, p_Sfalse_Cn)
                        
    H_Strue = H(p_Strue_Cp,p_Strue_Cn);
    H_Sfalse = H(p_Sfalse_Cp,p_Sfalse_Cn);
                    
    val = p_Strue*H_Strue + p_Sfalse*H_Sfalse;
    
end

function val = H(p_pos,p_neg)
    if p_pos == 0 || p_neg == 0 % corner case of log2
        val = 0;
    else
        val = - ( p_pos*log2(p_pos) + p_neg*log2(p_neg) );
    end
end