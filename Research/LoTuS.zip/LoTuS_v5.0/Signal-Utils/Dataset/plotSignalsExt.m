function h = plotSignalsExt(traces,t,labels,mode)
%plotSignalsExt plots a generic dataset using 
%   traces (data), t (sampling times), and labels.

[nobj, ndim, ntime] = size(traces);

if nargin < 3 || isempty(labels)
   labels = ones(nobj,1); 
end
if nargin < 4
   mode = "mc";
end

%uniq_labels = unique(labels)';
%nlabels = length(uniq_labels);
nlabels = max(labels);   

if mode == "1c"
    clabels = zeros(nobj,1);
    clabels = char(clabels);
    clabels(1:nobj) = 'b';  
elseif mode == "2c"  
    clabels = zeros(nobj,1);
    clabels = char(clabels);
    idx_1 = (labels ==  1);
    clabels( idx_1) = 'g';
    clabels(~idx_1) = 'r';
else % mode == "mc" 
    cols = defColorLines(nlabels);
    clabels = zeros(nobj,3);
    for i = 1:nobj
        clabels(i,:) = cols(labels(i),:);
    end
end


h = figure();
for j=1:ndim
    subplot(ndim,1,j);
    hold on
    for i = 1:nobj
        plot(t,squeeze(traces(i,j,:)),'Color',clabels(i,:))
    end
end

end