function [mcr, fpr, fnr, confmat] = treeEvalPerformance2C(T, signals, targetclass)
%treeEvalPerformance Evaluate the performance of a tree/formula 
%   Given a constructed tree T and a set of signals, compute some 
%   performance metrics.
%   mcr - missclassification rate
%   fpr - false positive rate
%   fnr - false negative rate
%   confmat - confusion matrix
%   targetclass - class considered "positive"

if nargin<3
    targetclass = 1;
else
    uniq_labels = unique(signals.labels)';
    if all(targetclass~=uniq_labels)
    	error('Target class not present in the provided dataset')
    end
end

nobj = size(signals.traces,1);

tp = 0;
fp = 0;
tn = 0;
fn = 0;

% compute confusion matrix
for j = 1:nobj
    s.t = signals.t;
    s.traces = signals.traces(j,:,:);
    s.labels = signals.labels(j);
    
    % check predicted label against the real one
    predclass = treeClassifyObj(T, s);
    
    if predclass == targetclass % predicting positives
        if s.labels == targetclass
            tp = tp+1;
        else % labels ~= targetclass
            fp = fp+1;
        end
    else % predclass ~= targetclass %predicting negatives
        if s.labels == targetclass
            fn = fn+1;
        else %s.labels ~= targetclass    
            tn = tn+1;
        end        
    end
    
end

% compute performance stats
confmat.tp = tp;
confmat.fp = fp;
confmat.tn = tn;
confmat.fn = fn;

num_realpos = tp+fn;
num_realneg = fp+tn;

mcr = (fp + fn)/(num_realneg+num_realpos);
fpr = fp / num_realneg; 
fnr = fn / num_realpos;

end

