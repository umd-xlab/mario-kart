function [signals_left, signals_right] = partitionSignals(PSTLformula, signals)
%partitionSignals divide signals in two groups according to best formula
%   also updates the computation of the robdeg for the signals so far

[lsat, robdeg_node] = primitiveCheckSat(PSTLformula, signals);

signals_left.t = signals.t;
signals_right.t = signals.t;

signals_left.traces = signals.traces(lsat,:,:);
signals_right.traces = signals.traces(~lsat,:,:);

if isfield(signals,'labels') %&& ~isempty(signals.labels)
    signals_left.labels = signals.labels(lsat);
    signals_right.labels = signals.labels(~lsat);
end

if isfield(signals,'robdeg')
    signals_left.robdeg = min(signals.robdeg(lsat),robdeg_node(lsat));
    signals_right.robdeg = min(signals.robdeg(~lsat),-robdeg_node(~lsat));
end

if isfield(signals,'Mdists')
    signals_left.Mdists = signals.Mdists(lsat,lsat);
    signals_right.Mdists = signals.Mdists(~lsat,~lsat);
end


end