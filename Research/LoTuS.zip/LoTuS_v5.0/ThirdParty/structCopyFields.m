function snew = structCopyFields(sold, fieldnames)
% copy structure with a subset of fields

for i=1:numel(fieldnames)
    if isfield(sold,fieldnames{i})
        snew.(fieldnames{i}) = sold.(fieldnames{i});
    end
end

end