% This script plots the SimpleDS2 dataset

%load SimpleDS1
load SimpleDS2

data = extractRandomSubset(data,0.1);
plotSignals(data);