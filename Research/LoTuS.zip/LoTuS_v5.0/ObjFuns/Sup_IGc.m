function objfunval = Sup_IGc(fstruct,fpars,signals)
%ObjFunMG_c Classic Information Gain 
%   Input
%   fstruct - PSTLprimitive structure
%   fpars - PSTLprimitive parameters
%   signals - a set of signals


traces = signals.traces;
t = signals.t;
labels = signals.labels;

% Check validity of the primitive 
if ~primitiveIsValid(fstruct,fpars,signals)
    objfunval = Inf;
    return;
end

% compute robustness degree for signals
robdeg = primitiveRobustness(fstruct,fpars,traces,t);

% Compute impurity-based cost function
% The cost function is just the variable part of the impurity measure.
% That is, if the cost is minimized, this in turn maximizes the purity gain
[p_Strue, p_Sfalse, p_Strue_Cp, p_Strue_Cn, ...
         p_Sfalse_Cp, p_Sfalse_Cn] = partitionWeightsC(robdeg, labels);

objfunval = IG_cost(p_Strue, p_Sfalse, p_Strue_Cp, p_Strue_Cn, ...
                 p_Sfalse_Cp, p_Sfalse_Cn);

end