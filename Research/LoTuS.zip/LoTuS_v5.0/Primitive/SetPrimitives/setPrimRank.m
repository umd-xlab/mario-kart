function [PSTLprimitives, vec_objfunvals] = setPrimRank(PSTLprimitives)
%selectBestPrimitiveOF returns the best primitive 
%   Order and return the best PSTL primitive according to the objective
%   function value. 

    vec_objfunvals = [PSTLprimitives.objfunval];
    [vec_objfunvals, sidx] = sort(vec_objfunvals);
    
    % reorder primitives
    PSTLprimitives = PSTLprimitives(sidx);
    
end