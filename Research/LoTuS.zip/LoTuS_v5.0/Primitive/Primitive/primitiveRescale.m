function PSTLprimitive = primitiveRescale(PSTLprimitive, scale, offset)

[fstruct, fpars] = v2struct(PSTLprimitive);

primtype = fstruct{1};
switch primtype
    case {'G','F'}
        fpars(3) = fpars(3)*scale(fstruct{2})+offset(fstruct{2});
    case {'FG','GF'}
        fpars(4) = fpars(4)*scale(fstruct{2})+offset(fstruct{2});
    otherwise
        error('Unsupported primitive');  
end

PSTLprimitive.fpars = fpars;

end