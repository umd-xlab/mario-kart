function PSTLprimitive = primitiveOptimization(PSTLprimitive, objfun, optzalg, optzalgconf, signals)
%primitiveOptimization Optimize a primitive
%   Find the best parameters for a given PSTLprimitive. At the moment this
%   is just a wrapper for calling the Simulated Annealing algorithm.
%   Inputs:
%   PSTLprimitive - uninitialized PSTL primitive (with parameter not assigned)
%   signals - a set of signals
%   prob_param - parameters for the optimization routine
%   Output:
%   PSTLprimitive - PSTL primitive with optimal parameter assigned 

[fstruct, fpars_init] = v2struct(PSTLprimitive);

problem = primitiveOpzProblem(fstruct, fpars_init, signals);

problem.objective = @(x) objfun(fstruct, x, signals);

optzalg_caller = str2func(optzalg);
if ~isfunction(optzalg_caller)
    error('Error: Optimization algorithm not recognized');
end

[PSTLprimitive.fpars, PSTLprimitive.objfunval] = optzalg_caller(problem, optzalgconf);
    
end
