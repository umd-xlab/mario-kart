function Mdists = DTWI_DistMatrix(X, warp_factor)

[Nobj, Ndim, Ntime] = size(X);
max_warp_len = round(Ntime*warp_factor);

Mdists = zeros(Nobj,Nobj);

for i=1:Nobj
    for j=i+1:Nobj
        for d=1:Ndim

            Mdists(i,j) = Mdists(i,j) + dtw(squeeze(X(i,d,:)), squeeze(X(j,d,:)), ...
                max_warp_len, 'squared');
            
        end
        Mdists(j,i) = Mdists(i,j);
    end
end

Mdists = sqrt(Mdists);

end