function [string_out, keep_flag] = treeToFormulaStrR(T, varargin)
%treeToFormulaStrR returns an STL formula corresponding to the tree T.
%(T, targetclass=1, node)
    
% If no node is passed. Start from root.
if nargin < 3
    node = 1;
else
    node = varargin{2};
end

% Set targetclass
if nargin < 2
    targetclass = 1;
else
    targetclass = varargin{1};
end

node_data = T.get(node);

% base case
if T.isleaf(node)   
   % consider only the path if ends with a positive leaf
   if node_data.predclass == targetclass
       string_out = [];
       keep_flag = 1;
   else 
       string_out = [];
       keep_flag = 0;
   end

else % recursion case
    listchildren = T.getchildren(node);
    leftnode = listchildren(1);
    rightnode = listchildren(2);

    PSTLformula_node = node_data.PSTLformula;
    
    string_node = primitiveToString(PSTLformula_node);
    PSTLformula_node_not = primitiveNegate(PSTLformula_node);
    string_node_neg = primitiveToString(PSTLformula_node_not);

    [string_left, keep_flag_left] = treeToFormulaStrR(T, targetclass, leftnode);
    [string_right, keep_flag_right] = treeToFormulaStrR(T, targetclass, rightnode);
    
    string_left  = string_and_formulae(...
                string_node    , string_left , keep_flag_left);
    string_right = string_and_formulae(...
                string_node_neg, string_right, keep_flag_right);

    [string_out, keep_flag] = string_or_formulae(...
        string_left, keep_flag_left, string_right, keep_flag_right);
    
end

end

function fs_out = string_and_formulae(fs_n, fs_st, keepflag)
%string_and_formulae returns the string of the conjunction of two formulae
    if keepflag
        if isempty(fs_st) 
            fs_out = fs_n;
        else
            fs_out = ['(', fs_n, ' \wedge ', fs_st, ')'];
        end
    else
        fs_out = [];
    end
end

function [fs_out, kf_out] = string_or_formulae(fs_l, kf_l, fs_r, kf_r)
%string_or_formulae returns the string of the disjunction of two formulae
    if kf_l && kf_r
        fs_out = ['(', fs_l, ' \vee ', fs_r, ')'];
        kf_out = 1;
    elseif kf_l
        fs_out = fs_l;
        kf_out = 1;
    elseif kf_r
        fs_out = fs_r;
        kf_out = 1;
    else
        fs_out = []; 
        kf_out = 0;
    end
end