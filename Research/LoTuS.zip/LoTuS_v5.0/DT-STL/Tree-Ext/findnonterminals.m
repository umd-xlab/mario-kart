function IDs = findnonterminals(T)

IDs = unique(T.Parent(2:end))';

end