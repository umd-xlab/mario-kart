function Mdists = EU_DistMatrix(X)

[Nobj, Ndim, Ntime] = size(X);

Mdists = zeros(Nobj,Nobj);

for i=1:Ndim
    data_i = squeeze(X(:,i,:));

    Mdists = Mdists + squareform(pdist(data_i,'squaredeuclidean'));

end

Mdists = sqrt(Mdists);

end