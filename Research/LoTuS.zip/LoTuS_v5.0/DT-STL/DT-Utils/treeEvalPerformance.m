function [mcr, confmat] = treeEvalPerformance(T, signals, num_labels)
%treeEvalPerformance Evaluate the performance of a tree/formula 
%   Given a constructed tree T and a set of signals, compute some 
%   performance metrics.
%   mcr - missclassification rate
%   fpr - false positive rate
%   fnr - false negative rate
%   confmat - confusion matrix


nobj = size(signals.traces,1);
predclass = zeros(nobj,1);

labels = signals.labels;

if nargin < 3
    %num_labels = unique(labels)';
    num_labels = 1:max(labels);
end

confmat = zeros(length(num_labels));

for j = 1:nobj
    s.t = signals.t;
    s.traces = signals.traces(j,:,:);
    s.labels = signals.labels(j);
    
    % check predicted label against the real one
    predclass(j) = treeClassifyObj(T, s);
    
end

% compute confusion matrix
% true ^ / pred >
for i = num_labels
    for j = num_labels
        confmat(i,j) = sum(predclass(labels == i) == j);
        %confmat(i+1,j+1) = sum(predclass(labels == i) == j);
    end
end

mcr = 1-trace(confmat)/nobj;

end

