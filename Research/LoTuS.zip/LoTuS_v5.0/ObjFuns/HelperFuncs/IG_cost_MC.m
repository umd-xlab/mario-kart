function val = IG_cost_MC(p_Strue, p_Sfalse, p_Strue_C, p_Sfalse_C)
                        
    H_Strue = H(p_Strue_C);
    H_Sfalse = H(p_Sfalse_C);
                    
    val = p_Strue*H_Strue + p_Sfalse*H_Sfalse;
    
end

function val = H(p)
    
    p(p == 0) = [];
    val = - sum(p.*log2(p));

end