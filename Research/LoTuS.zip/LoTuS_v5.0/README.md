## Installation
To install the package, just run `LoTuS_Init.m` script first.  
Information about the dataset format is contained in `CaseStudies/Dataset_Info.md`.    
Sample execution scripts are included in `CaseStudies/` and in the `ExecScripts/` folder.

## Requirements
This software has been tested with MATLAB R2019b on Windows 10.
However, it SHOULD work on any recent version of MATLAB/OS.
It requires the Optimization Toolbox and Signal Processing Toolbox.
Other third party libraries are included in the `ThirdParty/` directory. 


## Acknowledge this work 
To cite this work please use:  
1. G. Bombara and C. Belta, “Offline and Online Learning of Signal Temporal Logic Formulae using Decision Trees” in ACM Transactions on Cyber-Physical Systems, Vol 5, No 3, March 2021, doi: 10.1145/3433994   
2. G. Bombara and C. Belta, “Signal Clustering Using Temporal Logics” in Runtime Verification, Sep. 2017, pp. 121–137, doi: 10.1007/978-3-319-67531-2_8

Questions and bug reports can be sent to <gbombara@bu.edu>