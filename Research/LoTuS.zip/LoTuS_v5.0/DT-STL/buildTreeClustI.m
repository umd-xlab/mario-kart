function [T, debug] = buildTreeClustI(signals, varargin)

%
% Author: Giuseppe Bombara <gbombara@bu.edu> 
%         HyNeSs lab
%         Boston University


% default input values
prob_param = struct;

prob_param.primset = {'setPrim1','setPrim2','setPrim12'};
prob_param.objfun = listClustObjFuns();

prob_param.optzalg = listOptzAlgos();
prob_param.optzalgconf = [];   % 

prob_param.distance = {'euclidean','dtwi', 'dtwd'};
prob_param.warp_factor = 0.20;               % default warp factor 20%
prob_param.max_depth = 5;                    % max tree depth
prob_param.min_nobj = 10;                    % min number of signals in a node to continue recursion
prob_param.perc_gdiv_unexp = 0.01;           %
%prob_param.frac_same = 0.975;               % min fraction of same class signals in a node to stop recursion 

% process and validate inputs
try
    prob_param = parseargs(prob_param,varargin{:});
catch
    error(lasterr);
end

prob_param.primset = str2func(prob_param.primset);
if ~isfunction(prob_param.primset)
    error('Invalid primitive set');
end
prob_param.objfun = str2func(prob_param.objfun);
if ~isfunction(prob_param.objfun)
    error('Invalid objective function');
end

if (prob_param.max_depth < 0) || ...
   (prob_param.min_nobj  < 2) || ...
   (prob_param.perc_gdiv_unexp < 0) || (prob_param.perc_gdiv_unexp > 1) || ...
   (prob_param.warp_factor < 0) || (prob_param.warp_factor > 1)
    error('Invalid input parameters');
end

% Initialize the primitive set
sig_dim = size(signals.traces,2);
prob_param.PSTLprimitives = prob_param.primset(sig_dim);

% Main
T = tree();
parent_id = 0;

% augment the signal structure with robustness degrees for signals
Nobj = size(signals.traces,1);
signals.robdeg = Inf*ones(Nobj,1);

% compute Matrix of pairwise distances
signals.Mdists = computeDistMatrix(signals.traces,prob_param.distance,prob_param.warp_factor);

% Iterative Procedure to construct the tree
[T, root_id] = createLeaf(T, parent_id, signals);
subset_leaves = root_id;

if nargout>1
   i = 1;
   debug.T{i} = T;
   debug.perc_gdiv_unexp_iter(i) = computeUnexplainedDiversity(T);
   i = i + 1;
end

[stopIter, node_id] = findNodeToSplit(T, subset_leaves, prob_param);

while ~stopIter
    
    % Split the selected node
    [T, leftleaf_id, rightleaf_id] = splitSingleNode(T, node_id, prob_param);
    
    % Remove the node and add its children
    subset_leaves(subset_leaves == node_id) = [];
    subset_leaves = [subset_leaves, leftleaf_id, rightleaf_id];
    
    % %Debug
    % S = warning('QUERY', 'LTS:Debug');
    % if S.state == "on"
    %     treeViewPrimitives(T); 
    %     treeViewStats(T);
    % end
    
    [stopIter, node_id] = findNodeToSplit(T, subset_leaves, prob_param);
    
    if nargout>1 && ~isempty(leftleaf_id)
       debug.T{i} = T;
       debug.perc_gdiv_unexp_iter(i) = computeUnexplainedDiversity(T);
       i = i + 1;
    end

end

end

function [stopIter, node_id, perc_gdiv_unexp] = findNodeToSplit(T, subset_leaves, prob_param)

[perc_gdiv_unexp, max_gdiv_node_id] = computeUnexplainedDiversity(T, subset_leaves);

if isempty(subset_leaves) || perc_gdiv_unexp < prob_param.perc_gdiv_unexp
    stopIter = true;
    node_id = [];
else
    stopIter = false;
    node_id = max_gdiv_node_id;
end

end

function [perc_gdiv_unexp, max_gdiv_node_id] = computeUnexplainedDiversity(T, subset_leaves)

if nargin < 2 % use all leaves
    subset_leaves = T.findleaves();
end
nleaves = length(subset_leaves);

gdiv_red_leaves = zeros(1,nleaves);
for i = 1:nleaves
    node_data = T.get(subset_leaves(i));
    gdiv_red_leaves(i) = node_data.stats.gdiv_red;
end

perc_gdiv_unexp = sum(gdiv_red_leaves);

[~, id] = max(gdiv_red_leaves);
max_gdiv_node_id = subset_leaves(id);

end


function [T, leftleaf_id, rightleaf_id] = splitSingleNode(T, node_id, prob_param)

node_data = T.get(node_id);
signals = node_data.signals;
stats = node_data.stats;

% Check stopping conditions 
if checkStop(stats, prob_param)
    % No need to compute formula, store current node as leaf and return
    leftleaf_id = [];
    rightleaf_id = [];
    return;
end

% Find the best splitting formula from the primitive set
% along with its optimal parameters
PSTLformula = setPrimFindBest(prob_param.PSTLprimitives, prob_param.objfun, ...
    prob_param.optzalg, prob_param.optzalgconf, ...
    signals);

% Store current node
%node_data = prepareNodeData(stats, PSTLformula, signals);
node_data.PSTLformula = PSTLformula;
T = T.set(node_id, node_data);

% Split signals according to best formula
[signals_left, signals_right] = partitionSignals(PSTLformula, signals);

% check null split (unable to find a formula that further splits the data)
if checkNullSplit(signals_left,signals_right)
   warning('LTS:Warn','null split');
   leftleaf_id = [];
   rightleaf_id = [];
   return;
end

%
[T, leftleaf_id] = createLeaf(T, node_id, signals_left);
[T, rightleaf_id] = createLeaf(T, node_id, signals_right);

end

function [T, leaf_id] = createLeaf(T, parent_id, signals)

    [T, leaf_id] = T.addnode(parent_id, 'empty');

    stats = statsClustering(signals, T, leaf_id, parent_id);
    
    PSTLformula = [];
    node_data = v2struct(signals, PSTLformula, stats);
    
    T = T.set(leaf_id, node_data);

end

function stop = checkStop(stats, prob_param)
%checkStop Check stopping conditions  

    stop = false;
    
    % Stopping critera 
    if stats.node_depth >= prob_param.max_depth || ... % depth
        stats.nobj < prob_param.min_nobj %|| ... % number of obj
        %stats.gdiv_red < prob_param.min_gdiv_red || ...  % gdiv reduction
        %max(stats.fpos,stats.fneg) >= prob_param.frac_same || ... % purity
        stop = true;
    end

end