function T = treeRescalePrimitives(T, scale, offset)

iterator = findnonterminals(T);

for i = iterator
    node_data = T.get(i);
    node_data.PSTLformula = primitiveRescale(node_data.PSTLformula, scale, offset);
    T = T.set(i, node_data);
end

end