function data = scaleData(data,offset,scale)
%Rescale dataset globally so that the signals take values between [0 and 1]

%plotSignals(data);

ndim = size(data.traces,2);
for j=1:ndim
    data.traces(:,j,:) = data.traces(:,j,:)-offset(1,j);
    data.traces(:,j,:) = data.traces(:,j,:)/scale(1,j);
end

data.offset = offset;
data.scale = scale;

%plotSignals(data);

end