function data = scaleDataLZ(data)
%Rescale dataset so that the signals are (each) renormalized

%plotSignals(data);

% Rescale data
ndim = size(data.traces,2);

%
for j=1:ndim
    data.traces(:,j,:) = zscore(data.traces(:,j,:),[],1);
    %data(:,j,:) = zscore(data(:,j,:),[],3);
end

%plotSignals(data);

end