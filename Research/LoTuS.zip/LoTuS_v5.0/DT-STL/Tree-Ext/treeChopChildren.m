function T = treeChopChildren(T,node)
     listchildren = T.getchildren(node);
     leftnode = listchildren(1);
     T = T.chop(leftnode);
     rightnode = T.getchildren(node);
     T = T.chop(rightnode);
end
