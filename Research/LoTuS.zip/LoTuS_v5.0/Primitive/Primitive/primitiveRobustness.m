function rd = primitiveRobustness(fstruct,fpars,traces,t)
%primitiveRobustness computes the robustness of (a set of) signals
%   Input
%   fstruct - PSTLprimitive structure
%   fpars - PSTLprimitive parameters
%   traces - the signals sampled values
%   t - the sampling times

    %[fstruct, fpars] = v2struct(PSTLprimitive);

    primtype = fstruct{1};
    switch primtype
        case 'G'
            rd = fl_G(fstruct,fpars,traces,t);
        case 'F'
            rd = fl_F(fstruct,fpars,traces,t);
        case 'FG'
            rd = sl_FG(fstruct,fpars,traces,t);
        case 'GF'
            rd = sl_GF(fstruct,fpars,traces,t);
        otherwise
            error('Unsupported primitive');  
    end

end

function rd = fl_G(fstruct,fpars,traces,t)

    Nobj = size(traces,1);
    %temporalOper = fstruct{1};
    dim_idx = fstruct{2};
    ineq_dir = fstruct{3};

    tau1 = fpars(1);
    tau2 = fpars(2);
    space_par = fpars(3);
    
%     tol = eps*1e3;
%     if tau1 < t(1) || tau2 > t(end)+tol
%          %warning('LTS:Warn', 'Insufficient signal length for computing robustness'); 
%          rd = - Inf*ones(Nobj,1);
%          return;
%     end
    
    samptime = t(2)-t(1);
    i_tau1 = floor((tau1-t(1))/samptime)+1;
    i_tau2 = floor((tau2-t(1))/samptime)+1;
    
    rd = zeros(Nobj,1);
    tracesperm = permute(traces,[3 2 1]);
    switch ineq_dir
    case '<'
        for i=1:Nobj
            interval = tracesperm(i_tau1:i_tau2,dim_idx,i);
            %rd(i) = min(space_par - interval); 
            rd(i) = space_par - max(interval);
        end
    case '>'
        for i=1:Nobj
            interval = tracesperm(i_tau1:i_tau2,dim_idx,i);
            %rd(i) = min(- (space_par - interval) ); 
            rd(i) = min(interval) - space_par;    
        end
         
    end
     
end

function rd = fl_F(fstruct,fpars,traces,t)

    ineq_dir = fstruct{3};
    switch ineq_dir
    case '<'
        fstruct{3} = '>';
        rd = - fl_G(fstruct,fpars,traces,t);
    case '>'
        fstruct{3} = '<';
        rd = - fl_G(fstruct,fpars,traces,t);     
    end 

end

function rd = sl_FG(fstruct,fpars,traces,t)

    Nobj = size(traces,1);
    %temporalOper = fstruct{1};
    dim_idx = fstruct{2};
    ineq_dir = fstruct{3};

    tau1 = fpars(1);
    tau2 = fpars(2);
    tau3 = fpars(3);
    space_par = fpars(4);
    
%     tol = eps*1e3;
%     if tau1 < t(1) || tau2 > t(end)+tol || tau3 > t(end)-tau2
%          %warning('LTS:Warn', 'Insufficient signal length for computing robustness'); 
%          rd = - Inf*ones(Nobj,1);
%          return;
%     end
    
    samptime = t(2)-t(1);
    i_tau1 = floor((tau1-t(1))/samptime)+1;
    i_tau2 = floor((tau2-t(1))/samptime)+1;
    i_tmaxwin = min( floor((tau2+tau3-t(1))/samptime)+1, length(t) );
    win_size_samples = floor((tau3-0)/samptime)+1;
    
    rd = zeros(Nobj,1);
    tracesperm = permute(traces,[3 2 1]);
    switch ineq_dir
    case '<'
        for i=1:Nobj
            interval = tracesperm(i_tau1:i_tmaxwin,dim_idx,i);
            %pointrob = space_par - interval;
            %Grob = minmaxfilt1(pointrob, win_size_samples, 'min','valid');
            %rd(i) = max(Grob);
            
            winmaxdata = minmaxfilt1(interval, win_size_samples, 'max','valid');
            rd(i) = space_par - min(winmaxdata);
            
        end
    case '>'
        for i=1:Nobj
            interval = tracesperm(i_tau1:i_tmaxwin,dim_idx,i);
            %pointrob = - (space_par - interval);
            %Grob = minmaxfilt1(pointrob, win_size_samples, 'min','valid');
            %rd(i) = max(Grob);
            
            winmaxdata = minmaxfilt1(interval, win_size_samples,'min','valid');
            rd(i) = space_par - max(winmaxdata);
        end
         
    end
     
end

function rd = sl_GF(fstruct,fpars,traces,t)

    ineq_dir = fstruct{3};
    switch ineq_dir
    case '<'
        fstruct{3} = '>';
        rd = - sl_FG(fstruct,fpars,traces,t);
    case '>'
        fstruct{3} = '<';
        rd = - sl_FG(fstruct,fpars,traces,t);     
    end 
end
