function problem = primitiveOpzProblem(fstruct, fpars_init, signals)

%[fstruct, fpars_init] = v2struct(PSTLprimitive);

signalBounds = computeSignalsBounds(signals);

primtype = fstruct{1};
switch primtype
    case {'G','F'}
    problem = primitiveInitOpzFL(fstruct, fpars_init, signalBounds);
    case {'FG','GF'}
    problem = primitiveInitOpzSL(fstruct, fpars_init, signalBounds);
    otherwise
        error('Unsupported primitive');  
end
    
end

function problem = primitiveInitOpzFL(fstruct, fpars_init, signalBounds)

[time_bounds, space_bounds, min_sample_time] = v2struct(signalBounds);

sig_dim = fstruct{2};

% set up optmization routine options 
t_min = time_bounds(1);
t_max = time_bounds(2);
sig_dim_min = space_bounds(sig_dim,1);
sig_dim_max = space_bounds(sig_dim,2);

% mti: min_time_interval for Temporal Operator
mti = min_sample_time/2;

% tmin < t1 < tmax-mti
lb(1) = t_min;
ub(1) = t_max-mti;
% tmin+mti < t2 < tmax
lb(2) = t_min+mti;
ub(2) = t_max;
% xmin < x < xmax
lb(3) = sig_dim_min;
ub(3) = sig_dim_max;

%Optz Problem Structure
problem = struct();
problem.lb = lb;
problem.ub = ub;
problem.Aineq = [1,-1, 0];  % t2-t1>=mti, t1-t2<=-mti
problem.bineq = -mti;
%problem.Aeq � Matrix for linear equality constraints
%problem.beq � Vector for linear equality constraints
%problem.nonlcon � Nonlinear constraint function

% Create initial condition generator
    % Old Generator
    function mat = InitCondGenerator1(npoints)
        mat = zeros(npoints,3);  
        mat(:,1) = t_min          + ( (t_max - mti)*9/10 - t_min ).*rand(npoints,1);
        mat(:,2) = (mat(:,1)+mti) + ( t_max             - (mat(:,1)+mti) ).*rand(npoints,1);
        
        mat(:,3) = sig_dim_min    + ( sig_dim_max       - sig_dim_min).*rand(npoints,1);
        
        % If init condition is provided, use it
        if all(~isnan(fpars_init))
            mat(1,:) = fpars_init;
        end
    end

    % Diagonal Flip Generator
    function mat = InitCondGenerator2(npoints)
        mat = zeros(npoints,3);        
        mat(:,1) = t_min          + ( (t_max - mti)*9/10 - t_min ).*rand(npoints,1);        
        
        mat(:,2) = (t_min + mti)  + ( t_max - (t_min + mti) ).*rand(npoints,1);        
        idx = ( mat(:,2) < mat(:,1) + mti );
        tmp = mat(idx,2);
        mat(idx,2) = mat(idx,1) + mti;
        mat(idx,1) = tmp - mti;
        
        mat(:,3) = sig_dim_min    + ( sig_dim_max       - sig_dim_min).*rand(npoints,1);
        
        % If init condition is provided, use it
        if all(~isnan(fpars_init))
            mat(1,:) = fpars_init;
        end
    end

%tst = InitCondGenerator2(1000);
problem.InitCondGenerator = @InitCondGenerator2;
problem.x0 = problem.InitCondGenerator(1);

end

function problem = primitiveInitOpzSL(fstruct, fpars_init, signalBounds)

[time_bounds, space_bounds, min_sample_time] = v2struct(signalBounds);

sig_dim = fstruct{2};

% set up optmization routine options
t_min = time_bounds(1);
t_max = time_bounds(2);
sig_dim_min = space_bounds(sig_dim,1);
sig_dim_max = space_bounds(sig_dim,2);

% mti_i min_time_interval for inner temporal Operator
% mti_e min_time_interval for external temporal Operator
mti = min_sample_time/2;
mti_i = 4*min_sample_time; 

% tmin < t1 < tmax-mti_e
lb(1) = t_min;
ub(1) = t_max-mti;
% tmin+mti_e < t2 < tmax
lb(2) = t_min+mti;
ub(2) = t_max;
% mti_i < t3 < tmax
lb(3) = mti_i;
ub(3) = t_max;
% xmin < x < xmax
lb(4) = sig_dim_min;
ub(4) = sig_dim_max;

%Optz Problem Structure
problem = struct();
problem.lb = lb;
problem.ub = ub;

% t2-t1>=mti_e, t1-t2<=-mti_e
Aineq(1,:) = [1 -1 0 0]; bineq(1,1) = -mti;
% t2+t3 <= tmax
Aineq(2,:) = [0 1 1 0]; bineq(2,1) = t_max;

problem.Aineq = Aineq;
problem.bineq = bineq;
%problem.Aeq � Matrix for linear equality constraints
%problem.beq � Vector for linear equality constraints
%problem.nonlcon � Nonlinear constraint function

% Create initial condition generator
    % Old Generator
    function mat = InitCondGenerator1(npoints)
        mat = zeros(npoints,4);  
        mat(:,1) = t_min            + ( (t_max - mti)*9/10 - t_min ).*rand(npoints,1);
        mat(:,2) = (mat(:,1)+mti) + ( t_max-mti_i - (mat(:,1)+mti) ).*rand(npoints,1);
        mat(:,3) = mti_i            + ( (t_max-mat(:,2)) - mti_i ).*rand(npoints,1);
        mat(:,4) = sig_dim_min      + (sig_dim_max-sig_dim_min).*rand(npoints,1);
        
        % If init condition is provided, use it
        if all(~isnan(fpars_init))
            mat(1,:) = fpars_init;
        end
    end

    % Diagonal Flip Generator
    function mat = InitCondGenerator2(npoints)
        mat = zeros(npoints,3);        
        mat(:,1) = t_min          + ( (t_max - mti)*9/10 - t_min ).*rand(npoints,1);        
        
        %mat(:,2) = t_min + mti_e    + ( t_max-mti_i - (t_min + mti_e) ).*rand(npoints,1);        
        mat(:,2) = t_min + mti    + ( t_max - (t_min + mti) ).*rand(npoints,1);        
        idx = ( mat(:,2) < mat(:,1) + mti );
        tmp = mat(idx,2);
        mat(idx,2) = mat(idx,1) + mti;
        mat(idx,1) = tmp - mti;
        
        mat(:,3) = mti_i            + ( (t_max-mat(:,2)) - mti_i ).*rand(npoints,1);
        idx = (mat(:,3)+mat(:,2)) > t_max;
        mat(idx,2) = t_max-mti_i;
        mat(idx,3) = mti_i;
        
        mat(:,4) = sig_dim_min      + (sig_dim_max-sig_dim_min).*rand(npoints,1);
        
        % If init condition is provided, use it
        if all(~isnan(fpars_init))
            mat(1,:) = fpars_init;
        end
    end

%tst = InitCondGenerator2(1000);
problem.InitCondGenerator = @InitCondGenerator2;
problem.x0 = problem.InitCondGenerator(1);

end

function signalBounds = computeSignalsBounds(signals)
    % Compute parameter space bounds from input signals
    [~, ndim, ~] = size(signals.traces);
    space_bounds = zeros(ndim,2);
    for j=1:ndim
        signals_only_dimj = signals.traces(:,j,:);
        space_bounds(j,:) = [min(signals_only_dimj(:)),max(signals_only_dimj(:))];
    end
    time_bounds = [signals.t(1), signals.t(end)];
    min_sample_time = min(diff(signals.t)); % [Min interval length]
    
    tol = 1e-6;
    time_bounds(1)=time_bounds(1)+tol;
    time_bounds(2)=time_bounds(2)-tol;
    
    signalBounds = v2struct(time_bounds, space_bounds, min_sample_time);
    
end