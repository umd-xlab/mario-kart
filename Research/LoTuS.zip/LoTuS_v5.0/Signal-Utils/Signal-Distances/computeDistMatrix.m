function Mdists = computeDistMatrix(traces, distance, warp_factor)

switch distance
    case 'euclidean'
          Mdists = EU_DistMatrix(traces);
    case 'dtwd'
          Mdists = DTWD_DistMatrix(traces, warp_factor);
    case 'dtwi'
          Mdists = DTWI_DistMatrix(traces, warp_factor);
    otherwise
        warning('Unexpected Distance Case.')
end

end