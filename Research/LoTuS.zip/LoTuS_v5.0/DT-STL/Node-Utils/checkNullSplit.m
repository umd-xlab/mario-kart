function status = checkNullSplit(signals_left,signals_right)
%checkNullSplit check if a null/void split has been produced
    status = false;
    if isempty(signals_left.traces) || isempty(signals_right.traces)
       status = true;
    end
end