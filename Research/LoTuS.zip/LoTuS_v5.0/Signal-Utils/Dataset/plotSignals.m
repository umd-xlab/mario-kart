function h = plotSignals(signals, mode)
%plotSignals plots a generic dataset from the packed structure signals.
%   Signals contains the traces, the sampling times (t), and the labels.
%   the labels are optional

traces = signals.traces;
t = signals.t;

if isfield(signals,'labels')
    labels = signals.labels; 
else
    labels = []; 
end

if nargin < 2
   mode = "mc"; 
end

h = plotSignalsExt(traces,t,labels,mode);

end