function funs = listClustObjFuns(append)

persistent state

default = {'Clust_WGc'};

if isempty(state)
    state = default;
end

if nargin>0 && iscell(append) && size(append,1)==1
    state = horzcat(state, append);
end

funs = state;

end