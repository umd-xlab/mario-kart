function objfunval = Clust_WGc(fstruct,fpars,signals)
% Ward's gain
%   Input
%   fstruct - PSTLprimitive structure
%   fpars - PSTLprimitive parameters
%   signals - a set of signals


traces = signals.traces;
t = signals.t;
Mdists = signals.Mdists;
%labels = signals.labels;  % Not used!

Nobj = size(traces,1);

% Check validity of the primitive 
if ~primitiveIsValid(fstruct,fpars,signals)
    objfunval = Inf;
    return;
end

% compute robustness degree for signals
robdeg = primitiveRobustness(fstruct,fpars,traces,t);

% Sets Strue and Sfalse rapresented as index vectors on rd
Strue = (robdeg >= 0);
Sfalse = ~Strue;

p_true = sum(Strue)/Nobj;
p_false = 1 - p_true;

% Extract Data
Mdists_true = Mdists(Strue,Strue);
Mdists_false  = Mdists(Sfalse,Sfalse);

% Gain: Inertia(Node)-InertiaOfSplit
Ht = Inertia(Mdists_true);
Hf = Inertia(Mdists_false); 
objfunval = Ht*p_true + Hf*p_false;    %W

end
