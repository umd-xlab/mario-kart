function plotPruningProgression(nleaves_seq, perf_seq, idx_best)

nTree = length(nleaves_seq);

tree_idx_seq = cellstr(num2str([1:nTree]'));

figure();
plot(flip(nleaves_seq), flip(perf_seq));

xlabel("Num of Leaves"); 
%ylabel("Misclassification Rate (MCR)");
%set(gca, 'XTick', nleaves_seq(end):nleaves_seq(1))
xlim([nleaves_seq(end)-0.5,nleaves_seq(1)+0.5]);
ylim([0,max(perf_seq)+0.05]);


% Display points
tx = text(flip(nleaves_seq), flip(perf_seq), flip(tree_idx_seq), ...
    'VerticalAlignment','bottom', 'HorizontalAlignment', 'left');
if nargin == 3 
    tx(nTree-idx_best+1).Color = [0.8 0.0 1.0];
end

end