function best_STLformula = setPrimFindBest(PSTLprimitives, objfun, optzalg, optzalgconf, signals)
%findBestFormula Find the best splitting formula
%   Find the best splitting formula from the set of primitives 
%   along with its optimal parameters

% Find the optimal parameters for each primitive
PSTLprimitives = setPrimOptimization(PSTLprimitives, objfun, optzalg, optzalgconf, signals);
    
% Select the best overall primitive
best_STLformula = setPrimGetBest(PSTLprimitives);
    
end

function best_formula = setPrimGetBest(PSTLprimitives)
%selectBestPrimitiveOF returns the best primitive 
%   Order and return the best PSTL primitive according to the objective
%   function value. 
    
    vec_objfunvals = [PSTLprimitives.objfunval];
    [~,min_idx]=min(vec_objfunvals);
    best_formula = PSTLprimitives(min_idx);
    
end