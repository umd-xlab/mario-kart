function cols = defColorLines(nlabels)

%cols = lines(nlabels);
cols = distinguishable_colors(nlabels);

r = [1 0 0];
g = [0 1 0];
b = [0 0 1];

cols([1 2 3],:) = [g; r; b];

cols = cols(1:nlabels,:);

end