function T = treeResetLabels(T, predclass)
% reset every node to 'predclass' class

if nargin < 2
    predclass = 1;
end

iterator = T.nodeorderiterator;
for i = iterator
    T = treeLabelNode(T, i, predclass);
end

end