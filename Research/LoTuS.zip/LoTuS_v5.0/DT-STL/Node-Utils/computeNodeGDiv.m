function gdiv = computeNodeGDiv(Mdists)
    Nobj = size(Mdists,1);
    % Sum of squares
    gdiv = (1/2)*sum(Mdists,'all');
end