function tot_inertia = Inertia(Mdists)
% Variance

Nobj = size(Mdists,1);

if Nobj == 0
    tot_inertia = 0;
    return
end   

tot_inertia = (1/(2*Nobj^2))*sum(Mdists,'all');

%t = (1/(2*Nobj^2))*ones(Nobj,1)'*Mdists*ones(Nobj,1);

end
