function string_out = treeToFormulaStrI(T, targetclass)

if nargin<2
    targetclass = 1;
end

leaves_id = T.findleaves();

j=1;
pos_leaves_id=[];
for id = leaves_id
    node_data = T.get(id);
    if(node_data.predclass == targetclass)
        pos_leaves_id(j) = id;
        j = j + 1; 
    end
end

if isempty(pos_leaves_id)
   string_out = [];
   return  
end
nposleaves = length(pos_leaves_id);
leaves_strings = cell(nposleaves,1);

for i = 1:nposleaves
    path = T.findpath(1, pos_leaves_id(i));
    
    for j = 1:length(path)-1
        node_data = T.get(path(j));
        PSTLformula_node = node_data.PSTLformula;

        listchildren = T.getchildren(path(j));
        leftnode = listchildren(1);
        rightnode = listchildren(2);
        if leftnode == path(j+1)
            string_node = primitiveToString(PSTLformula_node);
        else
            [PSTLformula_not] = primitiveNegate(PSTLformula_node);
            string_node = primitiveToString(PSTLformula_not);
        end
        if isempty(leaves_strings{i})
            leaves_strings{i} = string_node;
        else
            leaves_strings{i} = [leaves_strings{i}, ' \wedge ', string_node];
        end
     end

end
%or among leaves_strings
string_out = ['\big( ', leaves_strings{1}, '\big) '];
for i = 2:nposleaves
    string_out = [string_out, ' \vee ', '\big( ', leaves_strings{i}, '\big) '];   
end


end
