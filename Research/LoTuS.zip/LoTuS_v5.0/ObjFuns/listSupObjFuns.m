function funs = listSupObjFuns(append)

persistent state

default = {'Sup_IGc','Sup_MGc'};

if isempty(state)
    state = default;
end

if nargin>0 && iscell(append) && size(append,1)==1
    state = horzcat(state, append);
end

funs = state;

end