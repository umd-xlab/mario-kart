%% tree-ref
lineage = tree.example;
disp(lineage.tostring)

%% The nnodes method returns the total number of nodes in a tree:
nnodes(lineage)

%% create/add/remove
t = tree('root');
[ t node1 ] = t.addnode(1, 'Node 1'); %% attach to root
[ t node2 ] = t.addnode(1, 'Node 2'); %% attach to root
[ t node11 ] = t.addnode(node1, 'Child of node 1'); %% attach to first node
disp(t.tostring)
t = t.removenode(node1);

%% access/set
t.get(1)  % the root content
t.get(n1) % first node content
t.get(n2) % etc...
t = t.set(n2, 'I changed.');

%% Grafting (innesto di due alberi) and chopping a branch
t = t.graft(targetNode, nt);
t = t.chop(targetNode);

%% Getting a branch as a subtree
lineage = tree.example;
t = lineage.subtree(19);

%% Copy tree
oneTree = tree(t, 1);
zeroTree = tree(t, 0);
optimisticTree = tree(t, 'I feel great!');
trueTree = tree(t, true);
zeroTree.issync(oneTree)

%% Most of the standard operators are implemented, and have their 
% element-wise meaning, with scalar expansion if needed. 
[ lineage, duration ] = tree.example;
a = (  ( duration .* (100 - duration.^2) ./ 5 ) ) < - duration;

%% Calling generic function on nodes content
t = lineage.subtree(19);
letterCount = t.treefun(@numel);
lastLetter = t.treefun2(letterCount, @(a, b) a(b));
disp(lastLetter.tostring) % Extract the last letter

%% Special methods
dt = t.depthtree;
ot = tree(t, 1); % Create a copy-tree filled with ones
nc = ot.recursivecumfun(@(x) sum(x) + 1);

%% Searching a tree for numerical data
indices = find ( duration > 15 );
for i = indices
    fprintf('The cell %s has an interphase duration of %d minutes.\n', ...
        lineage.get(i), ...
        duration.get(i) ); % We will speak of synchronized iteration later
end

% Are all durations longer than 2 minutes?
all( duration > 2 )

%% Searching a tree for text data
% Find the node named 'P3':
id_P3 = find( strcmp(lineage, 'P3') )
lineage.strrep('AB', 'P0a').regexprep('([a-z])', '\.$1').tostring

%% Traversing the tree and synchronized iteration
% depth first
df_order = tree(t, 'clear'); % Generate an empty synchronized tree
iterator = t.depthfirstiterator; % Doesn't matter whether you call this on |t| or |df_order|
index = 1;
for i = iterator
    df_order = df_order.set(i, index);
    index = index + 1;
end
disp(df_order.tostring)

% breadth-first
bf_order = tree(t, 'clear');
iterator = t.breadthfirstiterator;
index = 1;
for i = iterator
    bf_order = bf_order.set(i, index);
    index = index + 1;
end

% construction order
na_order = tree(t, 'clear');
iterator = t.nodeorderiterator;
index = 1;
for i = iterator
    na_order = na_order.set(i, index);
    index = index + 1;
end

%% Finding the shortest path between two nodes
lineage = tree.example;
n1 = find(lineage.strcmp('AB.plp'));
n2 = find(lineage.strcmp('C.a'));
path = lineage.findpath(n1, n2) %#ok<NOPTS>
pt = tree(lineage, 'clear');
index = 1;
for i = path
pt = pt.set(i, index);
index = index + 1;
end
disp(pt.tostring)

% return the index of the parent node. The root node has a parent index equals to 0.
getparent(node) 
% return the list of the children of this node. Leaf nodes get an empty list. The list is returned as a line vector.
getchildren(node) 
% return true is this node is a leaf node.
isleaf(node) 

%% Plot tree
figure('Position', [100 100 400 400])
[vlh, hlh, tlh] = slin.plot(sdur, 'YLabel', {'Division time' '(min)'});

%vlh contains the handle to the vertical lines that go below the node's location
%hlh contains the handle to the thick horizontal lines that link the node children
%tlh contains the handle to the node text item

rcolor = [ 0.6 0.2 0.2 ];
aboveTreshold = sdur > 10; % true if longer than 10 minutes
iterator = aboveTreshold.depthfirstiterator;
for i = iterator

   if  aboveTreshold.get(i)

       set( vlh.get(i), 'Color' , rcolor )
       set( hlh.get(i), 'Color' , rcolor )
       set( tlh.get(i), 'Color' , rcolor )

   end

end