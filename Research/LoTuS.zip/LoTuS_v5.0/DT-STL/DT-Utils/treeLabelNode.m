function T = treeLabelNode(T, node_id, predclass)

node_data = T.get(node_id);
node_data.predclass = predclass;
T = T.set(node_id,node_data);

end