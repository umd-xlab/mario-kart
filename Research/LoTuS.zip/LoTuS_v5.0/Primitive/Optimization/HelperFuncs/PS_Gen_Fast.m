function [x, fval] = PS_Gen_Fast(problem, optzalgconf)

problem.nvars = length(problem.x0);
problem.solver = 'particleswarm';
%problem.rngstate � Optional field to reset the state of the random number generator

options = optimoptions('particleswarm');
options.ObjectiveLimit = 0;
options.FunctionTolerance = 1e-3;  % 1e-06
options.MaxStallIterations = 10;  % 20
options.SwarmSize = 3*problem.nvars; % 10*nvars
%options.MaxIterations = 20*problem.nvars; % 200*nvars

function swarm = CustomCreationFcn(problemStruct)
    numParticles = problemStruct.options.SwarmSize;
    swarm = problem.InitCondGenerator(numParticles);
end
options.CreationFcn=@CustomCreationFcn;

%options.Display = 'diagnose';
options.Display = 'off';

if ~isempty(optzalgconf) && iscell(optzalgconf)
    options = optimoptions(options, optzalgconf{:});
end

problem.options = options;

[x,fval] = particleswarm(problem);

end