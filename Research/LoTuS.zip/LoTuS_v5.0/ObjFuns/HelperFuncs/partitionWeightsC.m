function [p_Strue, p_Sfalse, ...
          p_Strue_Cp, p_Strue_Cn, ...
          p_Sfalse_Cp, p_Sfalse_Cn] = partitionWeightsC(rd, labels)
      
    % Sets Strue and Sfalse rapresented as index vectors on rd
    Strue = (rd >= 0);
    Sfalse = ~Strue;

    p_Strue = sum(Strue)/length(labels);
    p_Sfalse = 1 - p_Strue;

    % true branch Strue (left)
    % Set Strue_Cp rapresented as index vector on absrd_Strue
    Strue_Cp = (labels(Strue) ==  1);
    %Strue_Cn = (labels(Strue) == 2);
    if isempty(Strue_Cp)  % handle corner case of empty branch
        p_Strue_Cp = 0.5;
    else
        p_Strue_Cp = sum(Strue_Cp)/length(Strue_Cp);
    end
    p_Strue_Cn = 1 - p_Strue_Cp;  
    

    % false branch Sfalse (right)
    % Set Sfalse_Cp rapresented as index vector on absrd_Sfalse
    Sfalse_Cp = (labels(Sfalse) ==  1);
    %Sfalse_Cn = (labels(Sfalse) == 2);
    if isempty(Sfalse_Cp)
        p_Sfalse_Cp = 0.5;  % handle corner case of empty branch
    else
        p_Sfalse_Cp = sum(Sfalse_Cp)/length(Sfalse_Cp);
    end
    p_Sfalse_Cn = 1 - p_Sfalse_Cp;
    
end