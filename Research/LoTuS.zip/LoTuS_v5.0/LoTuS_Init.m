% This script sets the MATLAB path for the package

thisdir = fileparts(mfilename('fullpath'));

addpath(fullfile(thisdir,'ThirdParty'));
addpath(fullfile(thisdir,'ThirdParty',filesep,'MinMaxFilter'));

addpath(fullfile(thisdir,'Signal-Utils'));
addpath(fullfile(thisdir,'Signal-Utils',filesep,'Dataset'));
addpath(fullfile(thisdir,'Signal-Utils',filesep,'ScaleDataset'));
addpath(fullfile(thisdir,'Signal-Utils',filesep,'Signal-Distances'));

addpath(fullfile(thisdir,'Primitive'));
addpath(fullfile(thisdir,'Primitive',filesep,'Primitive'));
addpath(fullfile(thisdir,'Primitive',filesep,'SetPrimitives'));
addpath(fullfile(thisdir,'Primitive',filesep,'Optimization'));
addpath(fullfile(thisdir,'Primitive',filesep,'Optimization','HelperFuncs'));

addpath(fullfile(thisdir,'ObjFuns',filesep,'HelperFuncs'));
addpath(fullfile(thisdir,'ObjFuns'));

addpath(fullfile(thisdir,'DT-STL'));
addpath(fullfile(thisdir,'DT-STL',filesep,'Node-Utils'));
addpath(fullfile(thisdir,'DT-STL',filesep,'Tree-Ext'));
addpath(fullfile(thisdir,'DT-STL',filesep,'DT-Utils'));
addpath(fullfile(thisdir,'DT-STL',filesep,'Online-Utils'));
addpath(fullfile(thisdir,'DT-STL',filesep,'Clust-Utils'));
addpath(fullfile(thisdir,'DT-STL',filesep,'Pruning'));


addpath(fullfile(thisdir,'ExecScripts'));
addpath(fullfile(thisdir,'ExecScripts',filesep,'Procedures'));

run(fullfile('CaseStudies', 'CS_Init.m'))

warning('OFF','LTS:Warn');
warning('OFF','LTS:Debug');

% debug code
if exist(fullfile(thisdir,'_ToyScripts'),'dir')
    addpath(fullfile(thisdir,'_ToyScripts'));
end

if exist(fullfile(thisdir,'_Debug'),'dir')
    run(fullfile('_Debug', 'Debug_Init.m'))
    warning('ON','LTS:Warn');
end

clear thisdir