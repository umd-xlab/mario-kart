function funs = listOptzAlgos(append)

persistent state

default = {'PS_Gen_Fast', 'PS_Gen', 'PS', 'SimAnneal'};

if isempty(state)
    state = default;
end

if nargin>0 && iscell(append) && size(append,1)==1
    state = horzcat(state, append);
end

funs = state;

end