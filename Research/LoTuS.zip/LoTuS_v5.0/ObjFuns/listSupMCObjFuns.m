function funs = listSupMCObjFuns(append)

persistent state

default = {'SupMC_IGc'};

if isempty(state)
    state = default;
end

if nargin>0 && iscell(append) && size(append,1)==1
    state = horzcat(state, append);
end

funs = state;

end