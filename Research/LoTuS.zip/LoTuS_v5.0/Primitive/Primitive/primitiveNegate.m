function [PSTLprimitive_neg] = primitiveNegate(PSTLprimitive)
%primitiveNegate logical negation of an input PSTL primitive

PSTLprimitive_neg = PSTLprimitive;

fs = PSTLprimitive.fstruct;

switch fs{1}
    case 'G'
        fs_neg{1} = 'F';
    case 'F'
        fs_neg{1} = 'G'; 
    case 'FG'
        fs_neg{1} = 'GF'; 
    case 'GF'
        fs_neg{1} = 'FG'; 
    otherwise
        error('Unsupported primitive');  
end

fs_neg{2} = fs{2};

if fs{3}== '<'
    fs_neg{3} = '>';
else 
    fs_neg{3} = '<';
end

PSTLprimitive_neg.fstruct = fs_neg;
    
end