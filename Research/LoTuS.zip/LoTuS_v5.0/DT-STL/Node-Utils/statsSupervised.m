function [stats, predclass] = statsSupervised(signals, T, node_id)
%computeStats compute some stats about the current node (used for stopping)

stats.node_depth = treeNodeDepth(T, node_id);

if ~isempty(signals.traces)
    stats.nobj = size(signals.traces,1);
else
    stats.nobj = 0;
end

if stats.nobj>0
    stats.nobj_pos = sum(signals.labels == 1);
    stats.nobj_neg = stats.nobj-stats.nobj_pos;
    stats.fpos = stats.nobj_pos/stats.nobj;
    stats.fneg = stats.nobj_neg/stats.nobj;
    
    stats.fclass = [stats.fpos, stats.fneg];
    
else
    stats.nobj_pos = 0;
    stats.nobj_neg = 0;
    stats.fpos = NaN;
    stats.fneg = NaN;
    
    stats.fclass = [stats.fpos, stats.fneg];
end

% assign label based on majority vote
if stats.nobj==0  % if node is empty, it's arbitrary
    predclass = 2;
elseif stats.fpos > stats.fneg  % more positives than negatives
    predclass = 1;
else
    predclass = 2;
end

% stats for pruning

% find fraction of training objects falling in this node
if treeIsNodeRoot(T, node_id)  % is root
    stats.fobj = 1;
else
    stats.fobj = stats.nobj/T.get(1).stats.nobj;
end

if predclass ==  1
    stats.r_err = stats.fneg;    
else
    stats.r_err = stats.fpos;
end
stats.R_err = stats.r_err*stats.fobj;

end