%% run algo
load Naval_2C

%% randomly shuffle data & split in training and testing
rng(0)
fuse = 1.0;    % use just a fraction of the dataset (debug)
ftrain = 0.8;
[train_data, test_data] = splitTrainTest(data, ftrain, fuse);


%%

% build the decision tree
tic()
T = buildTreeSup(train_data, 'optzalg','PS_Gen_Fast');
totalTime = toc()

% Display formula
disp(treeToFormulaStrR(T));

% Display formula performance
disp('Train set performance');
mcr_tr = treeEvalPerformance(T, train_data)

disp('Test set performance');
mcr_ts = treeEvalPerformance(T, test_data)

%% Post completition simplification
Tp_seq = pruningConstructTreeSeq(T);

T_best = pruningSelectBestTree_Sup(Tp_seq, test_data);


disp(treeToFormulaStrR(T_best));
mcr_pp = treeEvalPerformance(T_best, test_data)

