function [x, fval] = PS(problem, optzalgconf)

problem.nvars = length(problem.x0);
problem.solver = 'particleswarm';
%problem.rngstate — Optional field to reset the state of the random number generator

options = optimoptions('particleswarm');
options.ObjectiveLimit = 0;
options.FunctionTolerance = 1e-5;

%options.Display = 'diagnose';
options.Display = 'off';

if ~isempty(optzalgconf) && iscell(optzalgconf)
    options = optimoptions(options, optzalgconf{:});
end

problem.options = options;

[x,fval] = particleswarm(problem);

end
