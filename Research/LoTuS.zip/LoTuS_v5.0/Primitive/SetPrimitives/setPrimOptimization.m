function PSTLprimitives = setPrimOptimization(PSTLprimitives, objfun, optzalg, optzalgconf, signals)
%findBestFormula Find the best splitting formula
%   Find the best splitting formula from the set of primitives 
%   along with its optimal parameters

% Find the optimal parameters for each primitive
for m=1:length(PSTLprimitives)
    PSTLprimitives(m) = ...
        primitiveOptimization(PSTLprimitives(m), objfun, optzalg, optzalgconf, signals);
end
    
end