function [p_Strue, p_Sfalse, p_Strue_C, p_Sfalse_C] = partitionWeightsC_MC(rd, labels)
      
    % Sets Strue and Sfalse rapresented as index vectors on rd
    Strue = (rd >= 0);
    Sfalse = ~Strue;
    
    N_S = length(labels);
    N_Strue = sum(Strue);
    N_Sfalse = N_S - N_Strue;
    p_Strue = N_Strue/N_S;
    p_Sfalse = 1 - p_Strue;

    classes = unique(labels)';
    p_Strue_C = zeros(1,max(classes));
    p_Sfalse_C = zeros(1,max(classes));
    for i=classes
    
        % true branch Strue (left)
        % Set Strue_Cp rapresented as index vector on absrd_Strue
        Strue_Ci = (labels(Strue) ==  i);
        if N_Strue == 0         % handle corner case of empty branch
            p_Strue_C(i) = 0;  
        else 
            p_Strue_C(i) = sum(Strue_Ci)/N_Strue;
        end

        % false branch Sfalse (right)
        Sfalse_Ci = (labels(Sfalse) ==  i);
        if N_Sfalse == 0        % handle corner case of empty branch
            p_Sfalse_C(i) = 0;  
        else
            p_Sfalse_C(i) = sum(Sfalse_Ci)/N_Sfalse;
        end
        
    end
    
end