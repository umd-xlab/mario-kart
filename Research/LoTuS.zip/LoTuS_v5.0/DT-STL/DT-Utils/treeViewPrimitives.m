function treeViewPrimitives(T)

na_order = tree(T, 'clear');
iterator = T.nodeorderiterator;
index = 1;
for i = iterator
    node_data = T.get(i); 
    if T.isleaf(i)
        node_pstr = 'L';
        if isfield(node_data,'predclass')
            node_pstr = [node_pstr, '', num2str(node_data.predclass)];
        end
        node_pstr = [node_pstr, ' (Id', num2str(i), ')'];
    else
        node_pstr = primitiveToString(node_data.PSTLformula);            
        node_pstr = [node_pstr, ' (Id', num2str(i), ')'];
    end
    na_order = na_order.set(i, node_pstr);
    index = index + 1;
end
disp(na_order.tostring);

end