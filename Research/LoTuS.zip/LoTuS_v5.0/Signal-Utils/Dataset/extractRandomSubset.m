function data_rs = extractRandomSubset(data, fuse)
%extractRandomSubset return a random fraction of the data

if nargin < 2
    fuse = 1.0;
end

numTraces = size(data.traces,1);
randIndx = randperm(numTraces);

nPoints = floor(fuse*numTraces);
randIndx = randIndx(1:nPoints);

data_rs.traces = data.traces(randIndx,:,:);
data_rs.t = data.t;


if isfield(data,'labels') && ~isempty(data.labels)
    data_rs.labels = data.labels(randIndx);
end

end