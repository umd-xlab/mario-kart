function [x, fval] = SimAnneal(problem, optzalgconf)

problem.solver = 'simulannealbnd';
%problem.rngstate — Optional field to reset the state of the random number generator

options = optimoptions('simulannealbnd');
options.ObjectiveLimit = 0;
options.Display = 'off';
%options.Display = 'diagnose';
options.MaxFunctionEvaluations = 70*30;
options.ReannealInterval = 30;
%options.MaxFunctionEvaluations=Ns(1)*Ns(2);
%options.ReannealInterval = Ns(2);

if ~isempty(optzalgconf) && iscell(optzalgconf)
    options = optimoptions(options, optzalgconf{:});
end

problem.options = options; 

[x, fval] = simulannealbnd(problem);

end