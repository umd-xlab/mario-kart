function [T] = buildTreeSupOn(T, new_signal, varargin)

% default input values
prob_param = struct;

prob_param.primset = {'setPrim1','setPrim2','setPrim12'};
prob_param.objfun = {'Sup_MGc'};

prob_param.optzalg = listOptzAlgos();
prob_param.optzalgconf = [];   %

prob_param.always_update = false; % always Reoptimize Primitives in leaf (even if signal is correctly classified)
prob_param.reuse_sig = true;      % reuse signals from parent node (or not)
prob_param.splitconf = 0.90;      % confidence needed to select one primitive over the others.
prob_param.max_depth = 10;        % max tree depth
prob_param.frac_same = 0.98;     % max fraction of same class signals in a leaf to permit a split
prob_param.min_nobj = 50;         % min number of signals in a node to permit a split
prob_param.max_nobj = 250;        % max number of signals in a node (a split is forced)
prob_param.min_branch_nobj = 5;   % min number of signals in a resulting branch to allow split

% process and validate inputs
try
    prob_param = parseargs(prob_param,varargin{:});
catch
    error(lasterr);
end

prob_param.primset = str2func(prob_param.primset);
if ~isfunction(prob_param.primset)
    error('Invalid primitive set');
end
prob_param.objfun = str2func(prob_param.objfun);
if ~isfunction(prob_param.objfun)
    error('Invalid objective function');
end
if strcmp(prob_param.optzalg,'ParticleSwarm') && isempty(prob_param.optzalgconf) 
    prob_param.optzalgconf = {'MaxIterations', 40};   % 
end

if (prob_param.max_depth < 0) || ...
   (prob_param.frac_same < 0.55) || (prob_param.frac_same > 1) || ...
   (prob_param.min_nobj < 2) || (prob_param.min_nobj > prob_param.max_nobj) || ...
   (prob_param.min_branch_nobj < 1) || ...
   (prob_param.splitconf < 0.5) || (prob_param.splitconf >= 1)
    error('Invalid input parameters');
end

% Initialize the primitive set
sig_dim = size(new_signal.traces,2);
prob_param.PSTLprimitives = prob_param.primset(sig_dim);

% Main Part
if isempty(T)
    T = tree();
    parent_id = 0;
    T = createEmptyLeaf(T, parent_id, prob_param.PSTLprimitives);
end

[T, leaf_id, wrongPred] = locateAndStoreInLeaf(T, new_signal);

if wrongPred || prob_param.always_update
    T = UpdateLeaf(T, leaf_id, prob_param);
end

end


function T = UpdateLeaf(T, node_id, prob_param)

node_data = T.get(node_id);
PSTLprimitives = node_data.PSTLprimitives;
signals = node_data.signals;
stats = node_data.stats;

% Debug
% S = warning('QUERY', 'LTS:Debug');
% if S.state == "on"
%     treeViewStats(T);
%     treeViewStats(T.subtree(node_id));
% end

% check some confiditions before even attemping optimization (remove?)
trySplit = preEvaluateSplit(stats, prob_param);
if ~trySplit    
   return 
end

% Find the optimal parameters for each primitive
PSTLprimitives = setPrimOptimization(PSTLprimitives, prob_param.objfun, ...
                    prob_param.optzalg, prob_param.optzalgconf, ...
                    signals);

% evaluate split
[makeSplit, PSTLprimitives] = postEvaluateSplit(PSTLprimitives, stats, prob_param, signals);
node_data.PSTLprimitives = PSTLprimitives;

if ~makeSplit
    
    T = T.set(node_id, node_data);   
    
else
    
    best_PSTLformula = PSTLprimitives(1);
    node_data.PSTLformula = best_PSTLformula;
    
    T = T.set(node_id, node_data);
    
    % Split signals according to best formula
    [signals_left, signals_right] = partitionSignals(best_PSTLformula, signals);
    
    % create empty leaves 
    [T, leftleaf_id] = createEmptyLeaf(T, node_id, prob_param.PSTLprimitives);
    [T, rightleaf_id] = createEmptyLeaf(T, node_id, prob_param.PSTLprimitives);
    
    % reuse parent's signals
    if prob_param.reuse_sig == true
        T = storeInLeaf(T, leftleaf_id, signals_left);
        T = storeInLeaf(T, rightleaf_id, signals_right);
        
        T = UpdateLeaf(T, leftleaf_id, prob_param);
        T = UpdateLeaf(T, rightleaf_id, prob_param);
    end
    
end

end

function trySplit = preEvaluateSplit(stats, prob_param)

% Precond to avoid split
trySplit = true;

% max depth
if stats.node_depth >= prob_param.max_depth
    warning('LTS:Warn', 'PRE-ABORT: max depth');
    trySplit = false;
end

% purity
if max(stats.fpos,stats.fneg) > prob_param.frac_same
    warning('LTS:Warn', 'PRE-ABORT: frac_same');
    trySplit = false;
end

end

function [makeSplit, PSTLprimitives] = postEvaluateSplit(PSTLprimitives, stats, prob_param, signals)

[PSTLprimitives, vec_objfunvals] = setPrimRank(PSTLprimitives);
 
Delta_Gain = - (vec_objfunvals(1)-vec_objfunvals(1:end));

delta = 1-prob_param.splitconf;
eps = computeEps(delta,stats.nobj);

% avoid remove canditate primitive when there is insufficient data
if stats.nobj >= prob_param.min_nobj 
    keep_only = (Delta_Gain <= eps);
    PSTLprimitives = PSTLprimitives(keep_only);  
end

% Decide split

makeSplit = false;

if length(PSTLprimitives) == 1
    makeSplit = true;
    warning('LTS:Warn', 'confidence split');
end
if stats.nobj >= prob_param.max_nobj 
    makeSplit = true;  
    warning('LTS:Warn', 'max_nobj split');
end

% Post cond to avoid slit

if  makeSplit == true
    
    % low number of obj in children (almost empty split) 
    [signals_left, signals_right] = partitionSignals(PSTLprimitives(1), signals);
    if min(length(signals_left.labels),length(signals_right.labels)) < prob_param.min_branch_nobj
        warning('LTS:Warn', 'POST-ABORT: min_branch_nobj');
        makeSplit = false;
    end
    
    % absolute gain abort (gain against no split)
%     [ichildren, gain] = Sup_MG_c2(PSTLprimitives(1).fstruct,PSTLprimitives(1).fpars,signals);
%     if gain < eps
%         warning('LTS:Warn', 'POST-ABORT: low absolute gain');
%         %makeSplit = false;
%     end
    
    return

end

end

function eps = computeEps(delta,nS)
% Hoeffding's/Domingos Bound
%R = 1;
%eps = sqrt(((R^2)*log(1/delta))/(2*nS));


% Rutkowski Bound
%eps = sqrt((2*log(1/delta))/(nS));

% Rutkowski: Gaussian Aprrox Bound
quant = norminv(1-delta,0,1); 
eps = quant*sqrt(1/(2*nS));

end

function [T, leaf_id] = createEmptyLeaf(T, parent_id, PSTLprimitives)

[T, leaf_id] = T.addnode(parent_id, 'empty');

signals.traces = [];
signals.t = [];
signals.labels = [];
signals.robdeg = [];

[stats, ~] = statsSupervised(signals, T, leaf_id);

if parent_id ~= 0   % Use parent's label
    predclass = T.get(parent_id).predclass;
else % root random
    predclass = 2;
end

PSTLformula = [];

node_data = v2struct(signals, PSTLformula, predclass, stats, PSTLprimitives);

T = T.set(leaf_id, node_data);
    
end

function T = storeInLeaf(T, leaf_id, new_signals)

node_data = T.get(leaf_id);
signals = node_data.signals;

signals.traces = [signals.traces; new_signals.traces];
signals.t = new_signals.t;
signals.labels = [signals.labels; new_signals.labels];
signals.robdeg = [signals.robdeg; new_signals.robdeg];

[stats, predclass] = statsSupervised(signals, T, leaf_id);


nameOfStruct2Update = 'node_data';
node_data = v2struct(signals, stats, predclass, ... 
    nameOfStruct2Update, {'fieldNames', 'signals', 'stats', 'predclass'});

%PSTLformula = [];
%node_data = v2struct(signals, PSTLformula, predclass, stats, PSTLprimitives);

T = T.set(leaf_id, node_data);

end

function [T, leaf_id, wrongPred] = locateAndStoreInLeaf(T, signal)

% augment the signal structure with robustness degrees for the new signal
signal.robdeg = Inf*ones(1,1);
[leaf_id, signal, wrongPred] = locateLeaf(T, signal);

T = storeInLeaf(T, leaf_id, signal);

end


function [leaf_id, signal, wrongPred] = locateLeaf(T, signal, node)
%LOCATELEAF Summary of this function goes here
%   Detailed explanation goes here

if nargin<3
    node = 1;
end

node_data = T.get(node);

if T.isleaf(node)   % base case
    leaf_id = node;
    %GB% placeolder multiclass
    wrongPred = (node_data.predclass ~= signal.labels);
    
else % recursion case
    listchildren = T.getchildren(node);
    leftnode = listchildren(1);
    rightnode = listchildren(2);
    
    robdeg_path = signal.robdeg;
    
    [lsat, robdeg_node] = primitiveCheckSat(node_data.PSTLformula, signal);
      
    if lsat == +1 % left
        robdeg = min(robdeg_path,robdeg_node);
        signal.robdeg = robdeg;
        [leaf_id, signal, wrongPred] = locateLeaf(T, signal, leftnode);
    else % 0 right
        robdeg = min(robdeg_path,-robdeg_node);
        signal.robdeg = robdeg;
        [leaf_id, signal, wrongPred] = locateLeaf(T, signal, rightnode);
    end
      
end
  
end
