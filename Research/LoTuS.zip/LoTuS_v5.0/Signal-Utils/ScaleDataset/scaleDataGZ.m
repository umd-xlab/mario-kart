function data = scaleDataGZ(data)
%Rescale dataset so that the signals in dataset are globally renormalized

ndim = size(data.traces,2);
avg = zeros(1,ndim);
stdd = zeros(1,ndim);
for j=1:ndim
    signals_only_dimj = data.traces(:,j,:);
    avg(j) = mean(signals_only_dimj(:));
    stdd(j) = std(signals_only_dimj(:));
end

scale = stdd;
offset = avg;

data = scaleData(data,offset,scale);

end