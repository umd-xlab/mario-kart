% This toy scripts executes the train and test procedure on a dataset.

%% Load Dataset
load SimpleDS2


%% run procedure
rngstate = 'shuffle';
ftrain = 0.8;
tt_stats = Sup_TrainTest_Procedure(data,ftrain,rngstate)
    