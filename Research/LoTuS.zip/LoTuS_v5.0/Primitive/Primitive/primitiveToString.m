function pstring = primitiveToString(PSTLprimitive)
%primitiveToString returns the string rapresentation of a PSTL primitive

primtype = PSTLprimitive.fstruct{1};
switch primtype
    case {'G','F'}
        pstring = fl_print(PSTLprimitive);
    case 'FG'
        pstring = sl_FG_print(PSTLprimitive);
    case 'GF'
        pstring = sl_GF_print(PSTLprimitive);
    otherwise
        error('Unsupported primitive');  
end

end

function pstring = fl_print(PSTLprimitive)

[fstruct, fpars] = v2struct(PSTLprimitive);

ineq_dir = PSTLprimitive.fstruct{3};
if ineq_dir == '<'
%    ineq_dir = '\leq';
end

pstring = [fstruct{1}, '_{[', n2s(fpars(1)), ',', n2s(fpars(2)), ']}', ...
                   'x_{', n2s(fstruct{2}), '}', ineq_dir, n2s(fpars(3))];

end

function pstring = sl_FG_print(PSTLprimitive)

[fstruct, fpars] = v2struct(PSTLprimitive);

ineq_dir = PSTLprimitive.fstruct{3};
if ineq_dir == '<'
%    ineq_dir = '\leq';
end

pstring = ['F', '_{[', n2s(fpars(1)), ',', n2s(fpars(2)), ']}', ...
           'G', '_{[', n2s(0), ',', n2s(fpars(3)), ']}', ...
           'x_{', n2s(fstruct{2}), '}', ineq_dir, n2s(fpars(4))];

end

function pstring = sl_GF_print(PSTLprimitive)

[fstruct, fpars] = v2struct(PSTLprimitive);

ineq_dir = PSTLprimitive.fstruct{3};
if ineq_dir == '<'
%    ineq_dir = '\leq';
end

pstring = ['G', '_{[', n2s(fpars(1)), ',', n2s(fpars(2)), ']}', ...
           'F', '_{[', n2s(0), ',', n2s(fpars(3)), ']}', ...
           'x_{', n2s(fstruct{2}), '}', ineq_dir, n2s(fpars(4))];

end


function s = n2s(num)
    s = num2str(num,3);
end