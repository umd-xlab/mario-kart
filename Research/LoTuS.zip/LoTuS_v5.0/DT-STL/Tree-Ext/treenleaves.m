function [n] = treenleaves(T)

n = length(T.findleaves());

end