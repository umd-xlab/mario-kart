function [T] = buildTreeSupMC(signals, varargin)
%buildTreeSup builds a decision tree from a set of labeled signals
%    Input:
%    signals - It is a structure with three fields (traces,t,labels) in
%              the same format of the Dataset 
%              (see CaseStudies/Dataset_Info.txt)
%    varargin - a set of key-value attributes for the algorithm (optional!)
%       max_depth - max tree depth (>= 0)
%       frac_same - min fraction of same class signals in a node to stop recursion
%       min_nobj - min number of signals in a node to continue recursion (>= 2)
%
% Example function call
%   T = buildTreeSup(signals, 'max_depth', 3, 'frac_same', 0.99, 'min_nobj', 10)
%
% Last updated  10/01/19
%
% Author: Giuseppe Bombara <gbombara@bu.edu> 
%         HyNeSs lab
%         Boston University


% default input values
prob_param = struct;

prob_param.primset = {'setPrim1','setPrim2','setPrim12'};
prob_param.objfun = listSupMCObjFuns();

prob_param.optzalg = listOptzAlgos();
prob_param.optzalgconf = [];   % 

prob_param.max_depth = 5;      % max tree depth
prob_param.frac_same = 0.98;   % min fraction of same class signals in a node to stop recursion 
prob_param.min_nobj = 5;       % min number of signals in a node to continue recursion


% process and validate inputs
try
    prob_param = parseargs(prob_param,varargin{:});
catch
    error(lasterr);
end

prob_param.primset = str2func(prob_param.primset);
if ~isfunction(prob_param.primset)
    error('Invalid primitive set');
end
prob_param.objfun = str2func(prob_param.objfun);
if ~isfunction(prob_param.objfun)
    error('Invalid objective function');
end

if (prob_param.max_depth < 0) || ...
   (prob_param.frac_same < 0.55) || (prob_param.frac_same > 1) || ...
   (prob_param.min_nobj  < 2)
    error('Invalid input parameters');
end

% compute number of input classes
prob_param.numclass = max(signals.labels); 

% Initialize the primitive set
sig_dim = size(signals.traces,2);
prob_param.PSTLprimitives = prob_param.primset(sig_dim);

% Main
T = tree();
parent_id = 0;

% augment the signal structure with robustness degrees for signals
Nobj = size(signals.traces,1);
signals.robdeg = Inf*ones(Nobj,1);

% Generate tree starting with root note.
T = splitNode(T, parent_id, signals, prob_param);

end


function T = splitNode(T, parent_id, signals, prob_param)
%splitNode Recursively splits nodes
%    Input:
%    T - a Tree
%    signals - signals reaching the current node
%              It is a structure with four fields (traces,t,labels,robdeg) in
%              The first three fields are in the same format of 
%              the Dataset (see CaseStudies/Dataset_Info.txt)
%              Robdeg is a vector with the robustness degree of the signals
%              computed up to the parent node.
%    prob_param - optimization specific parameters

% create an empty node
[T, node_id] = T.addnode(parent_id, 'empty');

% compute some stats about the current node
[stats, predclass] = statsSupervisedMC(signals, T, node_id, prob_param.numclass);

% Check stopping conditions 
if checkStop(stats, prob_param)
    
    % No need to compute formula, store current node as leaf and return
    PSTLformula = [];
    node_data = v2struct(signals, PSTLformula, predclass, stats);
    T = T.set(node_id, node_data);
    return;
end

% Find the best splitting formula from the primitive set
% along with its optimal parameters
PSTLformula = setPrimFindBest(prob_param.PSTLprimitives, prob_param.objfun, ...
    prob_param.optzalg, prob_param.optzalgconf, ...
    signals);

% Store current node
node_data = v2struct(signals, PSTLformula, predclass, stats);
T = T.set(node_id, node_data);

% Split signals according to best formula
[signals_left, signals_right] = partitionSignals(PSTLformula, signals);

% check null split (unable to find a formula that further splits the data)
if checkNullSplit(signals_left,signals_right)
   warning('LTS:Warn','null split');
   return;
end

% Recurse for constructing the new nodes
T = splitNode(T, node_id, signals_left,  prob_param);
T = splitNode(T, node_id, signals_right, prob_param);

end

function stop = checkStop(stats, prob_param)
%checkStop Check stopping conditions  

    stop = false;
    
    % Stopping critera 
    if stats.node_depth >= prob_param.max_depth || ... % max depth
        stats.nobj < prob_param.min_nobj || ...  % number of obj
        max(stats.fclass) >= prob_param.frac_same  % purity

            stop = true;
    end

end
