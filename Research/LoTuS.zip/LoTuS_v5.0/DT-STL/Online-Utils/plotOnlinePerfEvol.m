function plotOnlinePerfEvol(mcr_vec)
%PLOTONLINEPERF Summary of this function goes here
%   Detailed explanation goes here

plot(mcr_vec,'LineWidth',1);
xlabel('Number of training signals');
ylabel('Misclassification rate (MCR)');

ylim([0 0.6])
ax = gca;
ax.YMinorTick = 'off';
ax.YTick = 0.00:0.05:0.60;
grid on;

end

