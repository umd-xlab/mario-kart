function data = scaleDataG11(data)
%Rescale dataset globally so that the signals take values between [-1 and 1]

ndim = size(data.traces,2);
space_bounds = zeros(2,ndim);
for j=1:ndim
    signals_only_dimj = data.traces(:,j,:);
    space_bounds(:,j) = [min(signals_only_dimj(:)),max(signals_only_dimj(:))];
end

scale = (1/2)*(space_bounds(2,:)-space_bounds(1,:));
offset = space_bounds(1,:)+scale(1,:);

data = scaleData(data,offset,scale);

end