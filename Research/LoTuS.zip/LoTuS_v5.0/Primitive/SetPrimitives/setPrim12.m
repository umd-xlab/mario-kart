function PSTLprimitives = setPrim12(num_signal_dim)
%setPrimInit creates a set of (unparametrized) Level 1 Primitives 
%   num_signal_dim - number of dimensions of the signals 
    
    c = 1;
    for dim_idx=1:num_signal_dim
        %% First level
        PSTLprimitives(c) = primitiveInitFL('G',dim_idx,'<');
        c = c + 1;
        PSTLprimitives(c) = primitiveInitFL('G',dim_idx,'>');
        c = c + 1;
        %% Second level
        PSTLprimitives(c) = primitiveInitSL('FG',dim_idx,'<');
        c = c + 1;
        PSTLprimitives(c) = primitiveInitSL('FG',dim_idx,'>');
        c = c + 1;
    end
    
end