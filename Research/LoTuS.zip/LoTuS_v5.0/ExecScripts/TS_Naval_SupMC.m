%% run algo
load Naval_3C

%% randomly shuffle data & split in training and testing
rng(0)
fuse = 1.0;    % use just a fraction of the dataset (debug)
ftrain = 0.8;
[train_data, test_data] = splitTrainTest(data, ftrain, fuse);


%%

% build the decision tree
tic()
T = buildTreeSupMC(train_data);
totalTime = toc()

% Display formula
disp(treeToFormulaStrR(T));

% Display formula performance
disp('Train set performance');
[mcr_tr, confmat] = treeEvalPerformance(T, train_data)

disp('Test set performance');
[mcr_ts, confmat] = treeEvalPerformance(T, test_data)

%% Post completition simplification
Tp_seq = pruningConstructTreeSeq(T);

T_best = pruningSelectBestTree_Sup(Tp_seq, test_data);


disp(treeToFormulaStrR(T_best));
[mcr_pp, confmat] = treeEvalPerformance(T_best, test_data)

