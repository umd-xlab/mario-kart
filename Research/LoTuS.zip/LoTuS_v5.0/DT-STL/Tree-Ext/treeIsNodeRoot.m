function isRoot = treeIsNodeRoot(T, node_id)

isRoot = (node_id == 1);

end