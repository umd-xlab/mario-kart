function plotOnlineTrainTestPerfEvol(mcr_tr_progr, mcr_ts_progr)

figure;
plotOnlinePerfEvol(mcr_tr_progr);
%figure;
hold on
plotOnlinePerfEvol(mcr_ts_progr);
legend('Train Set (Incremental)','Test Set (Full)');

end