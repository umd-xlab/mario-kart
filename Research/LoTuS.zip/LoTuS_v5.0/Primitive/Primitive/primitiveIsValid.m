function val = primitiveIsValid(fstruct, fpars, signals)
% Check validity of the primitive (also with respect to input signals)
    
    %[fstruct, fpars] = v2struct(PSTLprimitive);

    val = true;
    
    primtype = fstruct{1};
    
    switch primtype
        case {'G','F'}
            tau1 = fpars(1);
            tau2 = fpars(2);
            space_par = fpars(3);
            
            if tau1 > tau2
                %warning('LTS:Warn', 'Insufficient signal length for computing robustness'); 
                val=false;
                return;
            end  
        case {'FG','GF'}
            tau1 = fpars(1);
            tau2 = fpars(2);
            tau3 = fpars(3);
            space_par = fpars(4);
            
            if tau1 > tau2 || tau3 < 0
                %warning('LTS:Warn', 'Insufficient signal length for computing robustness'); 
                val=false;
                return;
            end 
        otherwise
            error('Unsupported primitive');  
    end
    
    if nargin == 3
        t = signals.t;
        min_sample_time = t(2)-t(1);
        
        switch primtype
            case {'G','F'}
                
                tmin = t(1);
                tmax = t(end);
                
                tol = min_sample_time/2;
                
                tau1 = fpars(1);
                tau2 = fpars(2);
                space_par = fpars(3);
                
                if tau1 < tmin || tau2 > tmax+tol
                     %warning('LTS:Warn', 'Insufficient signal length for computing robustness'); 
                     val=false;
                     return;
                end
            case {'FG','GF'}
                
                tmin = t(1);
                tmax = t(end);
                
                tol = min_sample_time/2;
                
                mti = min_sample_time/2;
                mti_i = 4*min_sample_time;
            
                tau1 = fpars(1);
                tau2 = fpars(2);
                tau3 = fpars(3);
                space_par = fpars(4);
                
                if tau1 < tmin || tau2 > tmax+tol || ...
                   tau3 + tau2 > tmax + tol || ...
                   tau3 < mti_i/2 
                     %warning('LTS:Warn', 'Insufficient signal length for computing robustness'); 
                     val=false;
                     return;
                end
            otherwise
                error('Unsupported primitive');  
        end    
    
    end

end