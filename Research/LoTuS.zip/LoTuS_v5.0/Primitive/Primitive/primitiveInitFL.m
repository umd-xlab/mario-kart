function PSTLprimitive = primitiveInitFL(temporalOper,dim_idx,ineq_dir)
    PSTLprimitive.fstruct = {temporalOper, dim_idx, ineq_dir};
    PSTLprimitive.fpars = [NaN NaN NaN];
    PSTLprimitive.objfunval = NaN;
end