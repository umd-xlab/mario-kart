## Dataset format

The data set must be struct with the following fields:

### data.traces:
Matrix of real numbers that contains the signals.  
Size: Nsignals x Ndim x Nsamples.  
Dim 1 - Signal  
Dim 2 - Dimension of a signal  
Dim 3 - Sampling times  

### data.t:
Row vector of real numbers containing the sampling times.  
Size: 1 x Nsamples.

### data.labels:
Column vector of positive integer numbers that contains the labels for the
signals in data.  
Size: Nsignals x 1.  
The Label must be 1 for the signals belonging to the positive/target class C_p.  
The Label must be 2 for the signals belonging to the negative/outlier class C_n.  

