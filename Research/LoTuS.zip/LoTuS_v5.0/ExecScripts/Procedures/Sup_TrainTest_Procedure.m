function [tt_stats] = Sup_TrainTest_Procedure(data,ftrain,rngstate,varargin)
%Sup_TrainTest_Procedure randomly splits the dataset and executes the learning
%and evaluation procedures
%   [traces,t,labels] - Input Dataset (see CaseStudies/Dataset_Info.txt)
%   ftrain - fraction of signals used for training (the rest are used for testing).
%   rngstate - set the the random number generator state 
%               (rngstate \geq 0 or [] for not using) 
%   varargin - extra arguments passed to buildTree

% Input handling
if nargin == 1 || isempty(ftrain) 
    ftrain=0.8;  
end
% restore random number generator state
if nargin > 2 && ~isempty(rngstate) 
    rng(rngstate)   
end

% save random generator state and randomly split in training and testing
rngstate = rng;
fuse = 1.0;          % use just a fraction of the dataset (debug)

[train_data, test_data] = splitTrainTest(data, ftrain, fuse);

% run the learning algorithm
tic()
T = buildTreeSup(train_data, varargin{:});
totalTime = toc()

% Display formula
disp(treeToFormulaStrR(T));

% Display formula performance
disp('Train set performance');
mcr_tr = treeEvalPerformance(T, train_data)
disp('Test set performance');
mcr_ts = treeEvalPerformance(T, test_data)

% Save some data of the exectution
tt_stats.rngstate = rngstate;
tt_stats.train_data = train_data;
tt_stats.test_data = test_data;
tt_stats.T = T;
tt_stats.totalTime = totalTime;
tt_stats.mcr_tr = mcr_tr;
tt_stats.mcr_ts = mcr_ts;

disp('Train and test completed!');

end