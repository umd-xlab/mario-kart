%% run algo
%load SimpleDS1
load Naval_2C

%% randomly shuffle data & split in training and testing
rng(0)
fuse = 1.0;    % use just a fraction of the dataset (debug)
ftrain = 0.8;
[train_data, test_data] = splitTrainTest(data, ftrain, fuse);


%%

% build the decision tree
T = [];

Ntrpoints = size(train_data.traces,1);
train_sofar.traces = [];
train_sofar.t = [];
train_sofar.labels = [];
mcr_tr_progr = zeros(1,Ntrpoints);
mcr_ts_progr = zeros(1,Ntrpoints);
T_progr = [];

tic()
j=1;
for i=1:Ntrpoints
    new_signal.traces = train_data.traces(i,:,:);
    new_signal.t = train_data.t;
    new_signal.labels = train_data.labels(i);
    
    T = buildTreeSupOn(T, new_signal);
    
    train_sofar.traces = [train_sofar.traces; new_signal.traces];
    train_sofar.t = new_signal.t;
    train_sofar.labels = [train_sofar.labels, new_signal.labels];
    mcr_tr_progr(i) = treeEvalPerformance(T, train_sofar);
    mcr_ts_progr(i) = treeEvalPerformance(T, test_data);
    
    % save T at major changing points
    if i>=2 && mcr_ts_progr(i) ~= mcr_ts_progr(i-1)
       T_progr(j).nobjtr = i; 
       T_progr(j).T = T;
       T_progr(j).mcr_ts = mcr_ts_progr(i);
       j = j + 1;
    end
    
end
totalTime = toc()

%% Test the final result

% Display formula
treeViewPrimitives(T)

% Display formula performance
disp('Train set performance');
mcr_tr = treeEvalPerformance(T, train_data)
disp('Test set performance');
mcr_ts = treeEvalPerformance(T, test_data)


%% Show training progression
plotOnlineTrainTestPerfEvol(mcr_tr_progr, mcr_ts_progr);
