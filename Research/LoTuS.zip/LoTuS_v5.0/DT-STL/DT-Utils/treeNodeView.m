function signals = treeNodeView(T, node_id)

node_data = T.get(node_id); 

if ~isfield(node_data,'signals')
    signals = [];
    return
end

signals = node_data.signals;

if nargout == 0
    plotSignals(signals);
end

end