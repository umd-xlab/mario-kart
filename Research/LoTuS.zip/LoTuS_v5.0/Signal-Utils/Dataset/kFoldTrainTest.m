function [train_data, test_data] = kFoldTrainTest(data_kf)


k_fold = numel(data_kf);

for nf=1:k_fold
    idx = (1:k_fold) ~= nf;
    
    train_data(nf).traces = vertcat(data_kf(idx).traces);
    train_data(nf).t = data_kf(1).t;
    train_data(nf).labels = vertcat(data_kf(idx).labels);

    test_data(nf).traces = vertcat(data_kf(nf).traces);
    test_data(nf).t = data_kf(nf).t;
    test_data(nf).labels = vertcat(data_kf(nf).labels);

end


end