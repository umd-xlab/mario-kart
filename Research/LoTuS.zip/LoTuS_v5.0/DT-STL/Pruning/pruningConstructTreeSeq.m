function [T_seq, alpha_seq] = pruningConstructTreeSeq(T_in)
%PRUNE Summary of this function goes here
%   Detailed explanation goes here


T_seq(1) = base_prune(T_in);
%T_seq(1) = T_in;

alpha_seq(1) = 0;
k = 1;
while ~(T_seq(k).isleaf(1))
     
     gTree = build_gTree(T_seq(k));
     
     alpha_seq(k+1) = findmin(gTree);     
     
     T_seq(k+1)=T_seq(k);
     prune_ids = find(gTree == alpha_seq(k+1));
     while ~isempty(prune_ids)
         
         T_seq(k+1) = treeChopChildren(T_seq(k+1), prune_ids(1));         
         gTree = gTree.set(prune_ids(1),Inf);
         gTree = treeChopChildren(gTree, prune_ids(1));  
         prune_ids = find(gTree == alpha_seq(k+1));
     end
     
     k = k + 1;

end

end

function [T] = base_prune(T)
    
    node_id = find_prunable_node(T);
    while node_id 
        T = treeChopChildren(T,node_id);
        node_id = find_prunable_node(T);
    end
    
end

function target_id = find_prunable_node(T)
%find a node n that has two leaf children with Rerr(n)=Rerr(l)+Rerr(r)
    target_id = 0;

    nonleaves_id = findnonterminals(T);
    for id=nonleaves_id
        listchildren = T.getchildren(id);
        leftnode = listchildren(1);
        rightnode = listchildren(2);
        if(T.isleaf(leftnode) && T.isleaf(rightnode))
            node_data = T.get(id);
            left_data = T.get(leftnode);
            right_data = T.get(rightnode);
            if(left_data.stats.R_err + right_data.stats.R_err >= node_data.stats.R_err)
                % just == shuold be fine
                target_id = id;
                return;
            end
        end
    end

end


function gTree = build_gTree(T)
    % find non terminal nodes
    gTree = tree(T, inf);
    nonleaves_id = findnonterminals(T);
    for i = nonleaves_id
        node_data = T.get(i);
        R_err = node_data.stats.R_err;
        val = (R_err - hat_Rerr_subtree(T,i)) / (numLeaves_subtree(T,i) - 1);
        gTree = gTree.set(i,val);
    end
      
end

function hat_R = hat_Rerr_subtree(T, i)
    if nargin<2
        i = 1;
    end
    
    subTi = T.subtree(i);
    leaves_id = subTi.findleaves();

    hat_R = 0;
    for lid=leaves_id
        node_data = subTi.get(lid);
        hat_R = hat_R + node_data.stats.R_err;
    end

end

function [n] = numLeaves_subtree(T,i)
    if nargin < 2
        i = 1;
    end
    subTi = T.subtree(i);
    leaves_id = subTi.findleaves();
    n = length(leaves_id);
end

function minVal = findmin(T)
    minVal = inf;
    iterator = T.breadthfirstiterator;
    for i = iterator
        nodeVal = T.get(i);
        if nodeVal < minVal
            minVal = nodeVal;
        end
    end
end


