function data_kf = kRandomPartition(data, k_fold)

[traces, t, labels] = v2struct(data);

numTraces = size(traces,1);
randIndx = randperm(numTraces);
 
traces = traces(randIndx,:,:);
labels = labels(randIndx);
 
% Divide the dataset in k_folds
edges_t = round(linspace(1,numTraces+1,k_fold+1));

for nf=1:k_fold
    idx  = edges_t(nf):edges_t(nf+1)-1;
    data_kf(nf).traces = traces(idx,:,:);
    data_kf(nf).t = t;
    data_kf(nf).labels = labels(idx);
end

end
