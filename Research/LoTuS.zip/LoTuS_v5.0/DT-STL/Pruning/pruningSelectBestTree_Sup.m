function [T_best, nleaves_seq, mcr_seq, idx_best] = pruningSelectBestTree_Sup(Tp_seq, test_data)

nTree = numel(Tp_seq);

% sequence of test mcr
mcr_best = Inf;
for i = 1:nTree
    mcr_seq(i) = treeEvalPerformance(Tp_seq(i), test_data);
    if mcr_seq(i) < mcr_best
        mcr_best = mcr_seq(i);
    end
end

% sequence of nleaves
for i = 1:nTree
    nleaves_seq(i) = treenleaves(Tp_seq(i));
end

% Use 2-SE Rule to pick one tree
num_test = size(test_data.traces,1);
SE_Best = sqrt(mcr_best*(1-mcr_best)/num_test);

idx_best = find(mcr_seq <= mcr_best+2*SE_Best, 1, 'last');
T_best = Tp_seq(idx_best);

% Create a plot: Num of Leaves Vs MCR, show tree index too
plotPruningProgression(nleaves_seq, mcr_seq, idx_best)

end
