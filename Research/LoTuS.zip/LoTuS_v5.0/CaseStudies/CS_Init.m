function CS_Init()
% This script sets the MATLAB path for the Case Studies

thisdir = fileparts(mfilename('fullpath'));
%addpath(fullfile(thisdir));

% Get a list of all files and folders in this folder.
if isempty(thisdir)
   thisdir = '.'; 
end
list = dir(thisdir);
list(1:2) = [];

% Get a logical vector that tells which is a directory.
dirFlags = [list.isdir];
% Extract only those that are directories.
subFolders = list(dirFlags);
% Print folder names to command window.
for k = 1 : length(subFolders)
	%fprintf('Sub folder #%d = %s\n', k, subFolders(k).name);
    addpath(fullfile(thisdir,subFolders(k).name));
end

%clear thisdir list dirFlags subFolders k

end
