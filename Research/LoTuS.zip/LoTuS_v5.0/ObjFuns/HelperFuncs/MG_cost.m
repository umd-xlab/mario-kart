function val = MG_cost(p_Strue, p_Sfalse, p_Strue_Cp, p_Strue_Cn, ...
                        p_Sfalse_Cp, p_Sfalse_Cn)
                           
    MR_Strue  = MR(p_Strue_Cp,p_Strue_Cn);
    MR_Sfalse = MR(p_Sfalse_Cp,p_Sfalse_Cn);
    
    val = p_Strue*MR_Strue + p_Sfalse*MR_Sfalse;
end

function val = MR(p_pos,p_neg)
    val = min(p_pos,p_neg);
end