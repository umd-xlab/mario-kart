function [cv_stats] = Sup_CrossVal_Procedure(data,k_fold,rngstate,varargin)
%Sup_CrossVal_Procedure preforms a k_fold cross validation on the dataset.
%   [traces,t,labels] - Input Dataset (see CaseStudies/Dataset_Info.txt)
%   k_fold - number of folds
%   rngstate - set the the random number generator state
%               (rngstate \geq 0 or [] for not using)
%   varargin - extra arguments passed to buildTree
%   cv_stats - statistics obtained from the cross-validation

% Input handling
if nargin == 1 || isempty(k_fold) 
    k_fold = 5;   
end
% restore random number generator state
if nargin > 2 && ~isempty(rngstate) 
    rng(rngstate)   
end

% save random generator state and randomly shuffle data
%rng(0)
rngstate = rng;

data_kp = kRandomPartition(data, k_fold);
[train_data, test_data] = kFoldTrainTest(data_kp);

% Perform the Cross-Validation
for nf=1:k_fold

    tic();
    T(nf) = buildTreeSup(train_data(nf),varargin{:});
    totalTime(nf) = toc();

    %disp(treeToFormulaStrR(T(nf)));
    mcr_tr(nf) = treeEvalPerformance(T(nf), train_data(nf));
    mcr_ts(nf) = treeEvalPerformance(T(nf), test_data(nf));

end

mean_time = mean(totalTime);
std_time = std(totalTime);
mean_tr_mcr = mean(mcr_tr);
std_tr_mcr = std(mcr_tr);
mean_mcr = mean(mcr_ts);
std_mcr = std(mcr_ts);

% Save all the CV stats.
cv_stats.rngstate = rngstate;
%cv_stats.k_fold = k_fold;
cv_stats.data_kp = data_kp;
cv_stats.T = T;
cv_stats.totalTime = totalTime;
cv_stats.mcr_tr = mcr_tr;
cv_stats.mcr_ts = mcr_ts;
cv_stats.mean_time = mean_time;
cv_stats.std_time = std_time;
cv_stats.mean_tr_mcr = mean_tr_mcr;
cv_stats.std_tr_mcr = std_tr_mcr;
cv_stats.mean_mcr = mean_mcr;
cv_stats.std_mcr = std_mcr;

disp('Cross-validation completed!');

end