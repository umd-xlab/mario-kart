%% load dataset
load Naval_3C_SZ

%% randomly shuffle data & split in training and testing
rng(0)
fuse = 1.00;    % use just a fraction of the dataset (debug)
ftrain = 0.8;
[train_data, test_data] = splitTrainTest(data, ftrain, fuse);


%%
% build the decision tree
tic()
[T, debug] = buildTreeClustI(train_data, 'max_depth', 3, 'distance', 'euclidean');
%[T, debug] = buildTreeClustI(train_data, 'max_depth', 3, 'distance', 'dtwd', 'warp_factor', 0.20);
totalTime = toc()

%% elbow analysis
plotElbowAnalysis(debug);

%% Extract subtree proper way (exploration/inspection)

% % Extract subtree of interest
Ti = debug.T{4};
treeViewPrimitives(Ti)
Ti_leaves_id = Ti.findleaves()
% 
% 
% % Explore leaves containing normal conditions and label them
sigs=treeNodeView(Ti,3); plotSignals(sigs);
sigs=treeNodeView(Ti,5); plotSignals(sigs);
sigs=treeNodeView(Ti,6); plotSignals(sigs);
sigs=treeNodeView(Ti,7); plotSignals(sigs);
% 
Ti=treeLabelNode(Ti,3,3);  %set leaf id4 as hjacking
Ti=treeLabelNode(Ti,5,2);  %set leaf id4 as trafficking
Ti=treeLabelNode(Ti,6,1);  %set leaf id4 as normal
Ti=treeLabelNode(Ti,7,1);  %set leaf id4 as normal
% 
% % Display formula performance
disp('Test set performance');
mcr_ts = treeEvalPerformance(Ti, test_data)
% 
% Display respective formula
% disp(treeToFormulaStrI(Ti));

%% Rescale tree to match original dataset
Ts = treeRescalePrimitives(Ti, data.scale, data.offset);
disp(treeToFormulaStrI(Ts));
