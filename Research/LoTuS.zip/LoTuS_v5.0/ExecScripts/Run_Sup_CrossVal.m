load Naval_2C

rngstate = 'shuffle';
k_fold = 5;
cv_stats = Sup_CrossVal_Procedure(data,k_fold,rngstate)
    