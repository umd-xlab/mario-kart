function depth = treeNodeDepth(T, node_id)
%treeNodeDepth returns the depth of the node "node_id" in the tree T.

    if node_id <= 0
        depth = -1;
    else
        depth = length(T.findpath(1, node_id))-1;
    end

end