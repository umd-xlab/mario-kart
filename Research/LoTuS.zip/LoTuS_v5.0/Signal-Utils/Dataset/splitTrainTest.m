function [train_data, test_data] = splitTrainTest(data, ftrain, fuse)
%splitTrainTest randomly split (a subset of) the dataset in training and testing sets

if nargin < 3
    fuse = 1;
end

if nargin < 2
    ftrain = 0.8;
end

data = extractRandomSubset(data, fuse);

numTraces = size(data.traces,1);
Ntrpoints = round(numTraces*ftrain);

train_data.traces = data.traces(1:Ntrpoints,:,:);
train_data.t = data.t;

test_data.traces = data.traces(Ntrpoints+1:end,:,:);
test_data.t = data.t;


if isfield(data,'labels')
    train_data.labels = data.labels(1:Ntrpoints);
    test_data.labels  = data.labels(Ntrpoints+1:end);
end

end