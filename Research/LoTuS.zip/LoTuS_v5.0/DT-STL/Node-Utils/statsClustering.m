function stats = statsClustering(signals, T, node_id, parent_id)
%computeStats compute some stats about the current node (used for stopping)

if isfield(signals,'labels')
    stats = statsSupervised(signals, T, node_id);
else    
    stats.node_depth = treeNodeDepth(T, node_id);

    if ~isempty(signals.traces)
        stats.nobj = size(signals.traces,1);
    else
        stats.nobj = 0;
    end 
end

if stats.nobj>0
    stats.gdiv = computeNodeGDiv(signals.Mdists);
    
    if treeIsNodeRoot(T, node_id)
        stats.gdiv_red = 1;
    else
        root_id = 1;
        %stats.gdiv_red = stats.gdiv/T.get(parent_id).stats.gdiv;
        %stats.gdiv_red= (stats.gdiv/T.get(root_id).stats.gdiv)*(stats.nobj/T.get(root_id).stats.nobj);
        stats.gdiv_red = (stats.gdiv/T.get(root_id).stats.gdiv);
    end  
else    
    stats.gdiv = 0;
    stats.gdiv_red = 0;
end

% Use gdiv_red
stats.R_err = stats.gdiv_red;

end
